package com.civiciq.repository;
import com.civiciq.model.NewsArticle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;
public interface NewsArticleRepository extends JpaRepository<NewsArticle, Long> {
    Page<NewsArticle> findByLanguageOrderByFetchedAtDesc(String language, Pageable pageable);
    Page<NewsArticle> findByCategoryAndLanguageOrderByFetchedAtDesc(String category, String language, Pageable pageable);
}
