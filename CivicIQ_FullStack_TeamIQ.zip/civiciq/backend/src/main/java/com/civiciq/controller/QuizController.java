package com.civiciq.controller;
import com.civiciq.model.Quiz;
import com.civiciq.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/quizzes") @RequiredArgsConstructor
public class QuizController {
    private final QuizRepository quizRepo;

    @GetMapping
    public ResponseEntity<List<Quiz>> getAllQuizzes(@RequestParam(required=false) String category) {
        return ResponseEntity.ok(category != null
            ? quizRepo.findByCategoryOrderByCreatedAtDesc(category)
            : quizRepo.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Quiz> getQuiz(@PathVariable Long id) {
        return quizRepo.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
}
