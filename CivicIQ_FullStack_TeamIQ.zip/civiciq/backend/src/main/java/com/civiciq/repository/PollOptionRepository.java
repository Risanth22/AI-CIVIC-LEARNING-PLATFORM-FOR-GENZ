package com.civiciq.repository;
import com.civiciq.model.PollOption;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PollOptionRepository extends JpaRepository<PollOption, Long> {}
