package com.civiciq.repository;
import com.civiciq.model.Bill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
public interface BillRepository extends JpaRepository<Bill, Long> {
    Page<Bill> findAllByOrderByPassedDateDesc(Pageable pageable);
}
