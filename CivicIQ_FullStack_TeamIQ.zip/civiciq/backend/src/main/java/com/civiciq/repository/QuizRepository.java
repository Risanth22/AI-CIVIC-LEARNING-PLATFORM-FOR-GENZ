package com.civiciq.repository;
import com.civiciq.model.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface QuizRepository extends JpaRepository<Quiz, Long> {
    List<Quiz> findByCategoryOrderByCreatedAtDesc(String category);
}
