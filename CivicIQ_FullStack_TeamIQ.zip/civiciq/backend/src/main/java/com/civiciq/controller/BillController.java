package com.civiciq.controller;
import com.civiciq.model.Bill;
import com.civiciq.repository.BillRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/bills") @RequiredArgsConstructor
public class BillController {
    private final BillRepository billRepo;

    @GetMapping
    public ResponseEntity<Page<Bill>> getBills(
            @RequestParam(defaultValue="0") int page,
            @RequestParam(defaultValue="10") int size) {
        return ResponseEntity.ok(billRepo.findAllByOrderByPassedDateDesc(PageRequest.of(page, size)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Bill> getBill(@PathVariable Long id) {
        return billRepo.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
}
