package com.civiciq.repository;
import com.civiciq.model.Poll;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface PollRepository extends JpaRepository<Poll, Long> {
    List<Poll> findByIsActiveTrueOrderByCreatedAtDesc();
}
