package com.civiciq.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name="news_articles") @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class NewsArticle {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    private String title;
    private String source;
    private String originalUrl;
    @Column(columnDefinition="TEXT") private String rawContent;
    @Column(columnDefinition="TEXT") private String aiSummary;
    private String category;
    private String language = "en";
    private LocalDateTime publishedAt;
    private LocalDateTime fetchedAt = LocalDateTime.now();
    private Boolean isVerified = true;
}
