package com.civiciq.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name="users") @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class User {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    private String name;
    @Column(unique=true) private String email;
    private String passwordHash;
    @Enumerated(EnumType.STRING) private Role role = Role.STUDENT;
    private String language = "en";
    private Boolean isVerified = false;
    private String avatarUrl;
    private Integer xpPoints = 0;
    private Integer streakDays = 0;
    private LocalDateTime createdAt = LocalDateTime.now();
    public enum Role { STUDENT, EDUCATOR, ADMIN }
}
