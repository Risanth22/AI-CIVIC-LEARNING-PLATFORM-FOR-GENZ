package com.civiciq.controller;
import com.civiciq.model.User;
import com.civiciq.repository.UserRepository;
import com.civiciq.security.JwtUtil;
import lombok.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController @RequestMapping("/api/auth") @RequiredArgsConstructor
public class AuthController {
    private final UserRepository userRepo;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req) {
        if (userRepo.existsByEmail(req.email()))
            return ResponseEntity.badRequest().body(Map.of("error","Email already registered"));
        User user = User.builder()
            .name(req.name()).email(req.email())
            .passwordHash(passwordEncoder.encode(req.password()))
            .role(User.Role.STUDENT).language(req.language() != null ? req.language() : "en")
            .build();
        userRepo.save(user);
        String token = jwtUtil.generateToken(user.getEmail(), user.getRole().name());
        return ResponseEntity.ok(Map.of("token", token, "user", toDto(user)));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        return userRepo.findByEmail(req.email())
            .filter(u -> passwordEncoder.matches(req.password(), u.getPasswordHash()))
            .map(u -> {
                String token = jwtUtil.generateToken(u.getEmail(), u.getRole().name());
                return ResponseEntity.ok(Map.of("token", token, "user", toDto(u)));
            })
            .orElse(ResponseEntity.status(401).body(Map.of("error","Invalid credentials")));
    }

    private Map<String, Object> toDto(User u) {
        return Map.of("id", u.getId(), "name", u.getName(),
            "email", u.getEmail(), "role", u.getRole(), "xp", u.getXpPoints());
    }

    record RegisterRequest(String name, String email, String password, String language) {}
    record LoginRequest(String email, String password) {}
}
