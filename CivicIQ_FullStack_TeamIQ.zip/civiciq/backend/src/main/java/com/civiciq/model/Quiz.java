package com.civiciq.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity @Table(name="quizzes") @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Quiz {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    private String title;
    private String category;
    @Enumerated(EnumType.STRING) private SourceType sourceType = SourceType.GENERAL;
    private Boolean generated = true;
    private LocalDateTime createdAt = LocalDateTime.now();
    @OneToMany(mappedBy="quiz", cascade=CascadeType.ALL, fetch=FetchType.LAZY)
    private List<QuizQuestion> questions;
    public enum SourceType { NEWS, BILL, CONSTITUTION, GENERAL }
}
