package com.civiciq.controller;
import com.civiciq.model.*;
import com.civiciq.repository.*;
import com.civiciq.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController @RequestMapping("/api/polls") @RequiredArgsConstructor
public class PollController {
    private final PollRepository pollRepo;
    private final PollVoteRepository voteRepo;
    private final PollOptionRepository optionRepo;
    private final UserRepository userRepo;

    @GetMapping
    public ResponseEntity<List<Poll>> getActivePolls() {
        return ResponseEntity.ok(pollRepo.findByIsActiveTrueOrderByCreatedAtDesc());
    }

    @GetMapping("/{id}/results")
    public ResponseEntity<Map<String, Object>> getPollResults(@PathVariable Long id) {
        return pollRepo.findById(id).map(poll -> {
            List<Object[]> counts = voteRepo.countVotesByPollId(id);
            long total = voteRepo.countByPollId(id);
            Map<Long, Long> voteCounts = new HashMap<>();
            for (Object[] row : counts) voteCounts.put((Long) row[0], (Long) row[1]);
            return ResponseEntity.ok(Map.of("poll", poll, "voteCounts", voteCounts, "total", total));
        }).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/{pollId}/vote")
    public ResponseEntity<?> vote(@PathVariable Long pollId, @RequestBody Map<String, Long> body,
                                   Authentication auth) {
        if (auth == null) return ResponseEntity.status(401).body("Login required");
        Long optionId = body.get("optionId");
        String email = auth.getName();
        User user = userRepo.findByEmail(email).orElseThrow();
        if (voteRepo.findByPollIdAndUserId(pollId, user.getId()).isPresent())
            return ResponseEntity.badRequest().body(Map.of("error","Already voted"));
        Poll poll = pollRepo.findById(pollId).orElseThrow();
        PollOption option = optionRepo.findById(optionId).orElseThrow();
        voteRepo.save(PollVote.builder().poll(poll).option(option).user(user).build());
        return ResponseEntity.ok(Map.of("message","Vote recorded"));
    }
}
