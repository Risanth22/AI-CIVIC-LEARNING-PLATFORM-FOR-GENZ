package com.civiciq.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity @Table(name="bills") @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Bill {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    private String billNumber;
    private String title;
    private LocalDate passedDate;
    private String ministry;
    @Column(columnDefinition="TEXT") private String rawText;
    @Column(columnDefinition="TEXT") private String aiSummary;
    @Column(columnDefinition="JSON") private String keyPoints;
    private String sourceUrl;
    private LocalDateTime createdAt = LocalDateTime.now();
}
