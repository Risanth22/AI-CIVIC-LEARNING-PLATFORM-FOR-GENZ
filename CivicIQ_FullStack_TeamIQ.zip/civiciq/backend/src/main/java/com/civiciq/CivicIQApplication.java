package com.civiciq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class CivicIQApplication {
    public static void main(String[] args) {
        SpringApplication.run(CivicIQApplication.class, args);
    }
}
