package com.civiciq.model;
import jakarta.persistence.*;
import lombok.*;

@Entity @Table(name="quiz_questions") @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class QuizQuestion {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @ManyToOne @JoinColumn(name="quiz_id") private Quiz quiz;
    @Column(columnDefinition="TEXT") private String question;
    private String optionA, optionB, optionC, optionD;
    @Enumerated(EnumType.STRING) private CorrectOpt correctOpt;
    @Column(columnDefinition="TEXT") private String explanation;
    @Enumerated(EnumType.STRING) private Difficulty difficulty = Difficulty.MEDIUM;
    public enum CorrectOpt { A, B, C, D }
    public enum Difficulty { EASY, MEDIUM, HARD }
}
