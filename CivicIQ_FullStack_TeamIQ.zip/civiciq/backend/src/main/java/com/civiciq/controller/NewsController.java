package com.civiciq.controller;
import com.civiciq.model.NewsArticle;
import com.civiciq.repository.NewsArticleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/news") @RequiredArgsConstructor
public class NewsController {
    private final NewsArticleRepository newsRepo;

    @GetMapping
    public ResponseEntity<List<NewsArticle>> getNews(
            @RequestParam(defaultValue="en") String lang,
            @RequestParam(defaultValue="0") int page,
            @RequestParam(defaultValue="10") int size,
            @RequestParam(required=false) String category) {
        var pageable = PageRequest.of(page, size);
        var articles = category != null
            ? newsRepo.findByCategoryAndLanguageOrderByFetchedAtDesc(category, lang, pageable)
            : newsRepo.findByLanguageOrderByFetchedAtDesc(lang, pageable);
        return ResponseEntity.ok(articles.getContent());
    }

    @GetMapping("/{id}")
    public ResponseEntity<NewsArticle> getById(@PathVariable Long id) {
        return newsRepo.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
}
