package com.civiciq.repository;
import com.civiciq.model.PollVote;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.Optional;
import java.util.List;
public interface PollVoteRepository extends JpaRepository<PollVote, Long> {
    Optional<PollVote> findByPollIdAndUserId(Long pollId, Long userId);
    @Query("SELECT v.option.id, COUNT(v) FROM PollVote v WHERE v.poll.id = :pollId GROUP BY v.option.id")
    List<Object[]> countVotesByPollId(Long pollId);
    long countByPollId(Long pollId);
}
