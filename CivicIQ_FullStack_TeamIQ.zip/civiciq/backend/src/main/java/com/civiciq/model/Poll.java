package com.civiciq.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity @Table(name="polls") @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Poll {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(columnDefinition="TEXT") private String question;
    private String category;
    @ManyToOne @JoinColumn(name="created_by") private User createdBy;
    private LocalDateTime expiresAt;
    private Boolean isActive = true;
    private LocalDateTime createdAt = LocalDateTime.now();
    @OneToMany(mappedBy="poll", cascade=CascadeType.ALL, fetch=FetchType.EAGER)
    private List<PollOption> options;
}
