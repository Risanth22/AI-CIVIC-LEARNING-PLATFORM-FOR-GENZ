package com.civiciq.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name="poll_votes") @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class PollVote {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @ManyToOne @JoinColumn(name="poll_id") private Poll poll;
    @ManyToOne @JoinColumn(name="option_id") private PollOption option;
    @ManyToOne @JoinColumn(name="user_id") private User user;
    private LocalDateTime votedAt = LocalDateTime.now();
}
