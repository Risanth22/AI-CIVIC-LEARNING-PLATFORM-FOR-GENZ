"""
CivicIQ Platform - Flask Backend
=================================
API Routes:
  /api/auth          - Register, Login
  /api/news          - News Feed + Summaries
  /api/bills         - Bill Passed Learning Module
  /api/quiz          - Quiz Bot (get questions + submit)
  /api/polls         - Civic Poll System
  /api/simulate      - Policy Simulations
  /api/tutor         - AI Civic Tutor Chat
  /api/topics        - Civic Knowledge Base
  /api/dashboard     - User Stats + Leaderboard
  /api/translate     - Sarvam AI Translation

Run:  python app.py
"""

import os
import sys
import json
import uuid
import secrets
import hashlib
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, request, jsonify, send_from_directory, make_response

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from db import (
    init_db, authenticate_user, create_user, get_user_by_id,
    get_news, get_news_by_id, get_bills, get_bill_by_id,
    get_quiz_questions, save_quiz_session,
    get_user_quiz_history, get_active_polls, get_poll_results,
    cast_poll_vote, get_simulations, get_simulation_by_id,
    save_simulation_run, get_topics, get_topic_by_id,
    save_tutor_message, get_tutor_history,
    get_platform_stats, get_leaderboard
)
from ai_engine import (
    civic_tutor_respond, summarize_for_genz,
    compute_simulation_outcome, call_sarvam_ai, translate_civic_content
)

# ─── APP SETUP ────────────────────────────────────────────────────────────────

app = Flask(__name__, static_folder='../frontend', static_url_path='')
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', secrets.token_hex(32))
app.config['JSON_SORT_KEYS'] = False

# In-memory session store (use Redis in production)
SESSIONS = {}


# ─── CORS (inline, no dependency) ────────────────────────────────────────────

@app.after_request
def add_cors_headers(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
    return response

@app.route('/', defaults={'path': ''}, methods=['OPTIONS'])
@app.route('/<path:path>', methods=['OPTIONS'])
def options_handler(path):
    return make_response('', 200)


# ─── AUTH HELPERS ─────────────────────────────────────────────────────────────

def create_session(user_id, role):
    token = secrets.token_hex(32)
    SESSIONS[token] = {
        'user_id': user_id,
        'role': role,
        'created_at': datetime.now().isoformat(),
        'expires_at': (datetime.now() + timedelta(days=7)).isoformat()
    }
    return token


def require_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if not token or token not in SESSIONS:
            return jsonify({'error': 'Authentication required', 'code': 401}), 401
        session = SESSIONS[token]
        request.current_user = session
        request.user_id = session['user_id']
        return f(*args, **kwargs)
    return decorated


def optional_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if token and token in SESSIONS:
            request.current_user = SESSIONS[token]
            request.user_id = SESSIONS[token]['user_id']
        else:
            request.current_user = None
            request.user_id = None
        return f(*args, **kwargs)
    return decorated


def success(data, message='Success', status=200):
    return jsonify({'success': True, 'message': message, 'data': data}), status


def error(message, status=400):
    return jsonify({'success': False, 'error': message}), status


# ─── STATIC FILES ─────────────────────────────────────────────────────────────

@app.route('/')
def serve_index():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    full = os.path.join(app.static_folder, path)
    if os.path.exists(full):
        return send_from_directory(app.static_folder, path)
    return send_from_directory(app.static_folder, 'index.html')


# ─── HEALTH CHECK ─────────────────────────────────────────────────────────────

@app.route('/api/health', methods=['GET'])
def health():
    return success({
        'status': 'running',
        'version': '1.0.0',
        'platform': 'CivicIQ',
        'timestamp': datetime.now().isoformat()
    })


# ─── AUTH ROUTES ──────────────────────────────────────────────────────────────

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    username = data.get('username', '').strip()
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')
    language = data.get('language', 'en')

    if not username or not email or not password:
        return error('Username, email and password are required')
    if len(password) < 6:
        return error('Password must be at least 6 characters')
    if '@' not in email:
        return error('Invalid email address')

    ok, msg = create_user(username, email, password, language=language)
    if not ok:
        return error(msg)

    user = authenticate_user(email, password)
    token = create_session(user['id'], user['role'])
    return success({
        'token': token,
        'user': {
            'id': user['id'],
            'username': user['username'],
            'email': user['email'],
            'role': user['role'],
            'xp_points': user['xp_points'],
            'preferred_language': user['preferred_language']
        }
    }, 'Account created successfully', 201)


@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if not email or not password:
        return error('Email and password required')

    user = authenticate_user(email, password)
    if not user:
        return error('Invalid email or password', 401)

    token = create_session(user['id'], user['role'])
    return success({
        'token': token,
        'user': {
            'id': user['id'],
            'username': user['username'],
            'email': user['email'],
            'role': user['role'],
            'xp_points': user['xp_points'],
            'preferred_language': user['preferred_language']
        }
    }, 'Login successful')


@app.route('/api/auth/me', methods=['GET'])
@require_auth
def get_me():
    user = get_user_by_id(request.user_id)
    if not user:
        return error('User not found', 404)
    user.pop('password_hash', None)
    return success(user)


@app.route('/api/auth/logout', methods=['POST'])
@require_auth
def logout():
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    SESSIONS.pop(token, None)
    return success({}, 'Logged out successfully')


# ─── NEWS ROUTES ──────────────────────────────────────────────────────────────

@app.route('/api/news', methods=['GET'])
@optional_auth
def get_news_feed():
    category = request.args.get('category', 'all')
    limit = min(int(request.args.get('limit', 10)), 50)
    offset = int(request.args.get('offset', 0))
    news = get_news(category, limit, offset)
    return success({'articles': news, 'count': len(news), 'offset': offset})


@app.route('/api/news/<int:news_id>', methods=['GET'])
@optional_auth
def get_single_news(news_id):
    article = get_news_by_id(news_id)
    if not article:
        return error('Article not found', 404)
    return success(article)


@app.route('/api/news/<int:news_id>/summary', methods=['GET'])
@optional_auth
def get_news_summary(news_id):
    article = get_news_by_id(news_id)
    if not article:
        return error('Article not found', 404)
    
    lang = request.args.get('lang', 'en')
    summary = article.get('simplified_summary') or summarize_for_genz(
        article['original_title'],
        article.get('original_content', ''),
        article.get('category', '')
    )
    
    if lang != 'en':
        summary = translate_civic_content(summary, lang)
    
    return success({'summary': summary, 'article_id': news_id, 'language': lang})


# ─── BILLS ROUTES ─────────────────────────────────────────────────────────────

@app.route('/api/bills', methods=['GET'])
@optional_auth
def get_bills_list():
    limit = min(int(request.args.get('limit', 10)), 50)
    bills = get_bills(limit)
    return success({'bills': bills, 'count': len(bills)})


@app.route('/api/bills/<int:bill_id>', methods=['GET'])
@optional_auth
def get_single_bill(bill_id):
    bill = get_bill_by_id(bill_id)
    if not bill:
        return error('Bill not found', 404)
    
    lang = request.args.get('lang', 'en')
    if lang != 'en' and bill.get('simplified_explanation'):
        bill['simplified_explanation'] = translate_civic_content(
            bill['simplified_explanation'], lang
        )
    return success(bill)


# ─── QUIZ ROUTES ──────────────────────────────────────────────────────────────

@app.route('/api/quiz/questions', methods=['GET'])
@optional_auth
def get_questions():
    category = request.args.get('category', 'all')
    difficulty = request.args.get('difficulty', 'all')
    limit = min(int(request.args.get('limit', 10)), 20)
    questions = get_quiz_questions(category, difficulty, limit)
    
    # Strip correct_option from response (security)
    safe_questions = []
    for q in questions:
        safe_q = {k: v for k, v in q.items() if k not in ('correct_option', 'explanation')}
        safe_questions.append(safe_q)
    
    return success({'questions': safe_questions, 'total': len(safe_questions)})


@app.route('/api/quiz/submit', methods=['POST'])
@require_auth
def submit_quiz():
    data = request.get_json() or {}
    answers = data.get('answers', {})   # {question_id: selected_option}
    category = data.get('category', 'general')
    time_sec = data.get('time_taken_seconds', 0)

    if not answers:
        return error('No answers provided')

    # Fetch correct answers
    question_ids = list(answers.keys())
    from db import get_db
    conn = get_db()
    results = []
    correct_count = 0
    
    for qid in question_ids:
        row = conn.execute(
            "SELECT id, correct_option, explanation FROM quiz_questions WHERE id=?",
            (int(qid),)
        ).fetchone()
        if row:
            is_correct = answers[qid].lower() == row['correct_option'].lower()
            if is_correct:
                correct_count += 1
            results.append({
                'question_id': int(qid),
                'selected': answers[qid],
                'correct': row['correct_option'],
                'is_correct': is_correct,
                'explanation': row['explanation']
            })
    conn.close()

    total = len(results)
    session_id, score, xp_earned = save_quiz_session(
        request.user_id, category, total, correct_count, time_sec
    )

    return success({
        'session_id': session_id,
        'total': total,
        'correct': correct_count,
        'score_percent': score,
        'xp_earned': xp_earned,
        'results': results
    }, f'Quiz completed! Score: {score}%')


@app.route('/api/quiz/history', methods=['GET'])
@require_auth
def quiz_history():
    history = get_user_quiz_history(request.user_id)
    return success({'history': history})


@app.route('/api/quiz/categories', methods=['GET'])
def quiz_categories():
    return success({'categories': [
        {'id': 'all', 'label': 'All Topics', 'emoji': '🎯'},
        {'id': 'constitution', 'label': 'Constitution', 'emoji': '📜'},
        {'id': 'governance', 'label': 'Parliament & Governance', 'emoji': '🏛️'},
        {'id': 'election', 'label': 'Elections & Voting', 'emoji': '🗳️'},
        {'id': 'policy', 'label': 'Government Policies', 'emoji': '📊'},
        {'id': 'judiciary', 'label': 'Judiciary & Courts', 'emoji': '⚖️'},
    ]})


# ─── POLLS ROUTES ─────────────────────────────────────────────────────────────

@app.route('/api/polls', methods=['GET'])
@optional_auth
def get_polls():
    polls = get_active_polls()
    return success({'polls': polls, 'count': len(polls)})


@app.route('/api/polls/<int:poll_id>/results', methods=['GET'])
@optional_auth
def poll_results(poll_id):
    result = get_poll_results(poll_id)
    if not result:
        return error('Poll not found', 404)
    return success(result)


@app.route('/api/polls/<int:poll_id>/vote', methods=['POST'])
@require_auth
def vote_on_poll(poll_id):
    data = request.get_json() or {}
    option = data.get('option', '').lower()

    if option not in ('a', 'b', 'c', 'd'):
        return error('Invalid option. Must be a, b, c, or d.')

    ok, msg = cast_poll_vote(poll_id, request.user_id, option)
    if not ok:
        return error(msg)

    results = get_poll_results(poll_id)
    return success({'results': results}, 'Vote recorded!')


# ─── SIMULATION ROUTES ────────────────────────────────────────────────────────

@app.route('/api/simulate', methods=['GET'])
@optional_auth
def list_simulations():
    sims = get_simulations()
    return success({'simulations': sims, 'count': len(sims)})


@app.route('/api/simulate/<int:sim_id>', methods=['GET'])
@optional_auth
def get_simulation(sim_id):
    sim = get_simulation_by_id(sim_id)
    if not sim:
        return error('Simulation not found', 404)
    return success(sim)


@app.route('/api/simulate/<int:sim_id>/run', methods=['POST'])
@optional_auth
def run_simulation(sim_id):
    sim = get_simulation_by_id(sim_id)
    if not sim:
        return error('Simulation not found', 404)

    user_params = request.get_json() or {}
    outcome = compute_simulation_outcome(sim_id, user_params, sim)

    if request.user_id:
        save_simulation_run(sim_id, request.user_id, user_params, outcome)

    return success({
        'simulation': sim['title'],
        'your_params': user_params,
        'outcome': outcome
    }, 'Simulation complete!')


# ─── TUTOR ROUTES ─────────────────────────────────────────────────────────────

@app.route('/api/tutor/chat', methods=['POST'])
@optional_auth
def tutor_chat():
    data = request.get_json() or {}
    message = data.get('message', '').strip()
    language = data.get('language', 'en')
    session_id = data.get('session_id', str(uuid.uuid4()))

    if not message:
        return error('Message is required')
    if len(message) > 1000:
        return error('Message too long (max 1000 chars)')

    history = []
    if request.user_id:
        history = get_tutor_history(request.user_id, session_id)

    response = civic_tutor_respond(message, language, history)

    if request.user_id:
        save_tutor_message(request.user_id, session_id, 'user', message, language)
        save_tutor_message(request.user_id, session_id, 'assistant', response, language)

    return success({
        'response': response,
        'session_id': session_id,
        'language': language,
        'timestamp': datetime.now().isoformat()
    })


@app.route('/api/tutor/history', methods=['GET'])
@require_auth
def get_chat_history():
    session_id = request.args.get('session_id')
    if not session_id:
        return error('session_id required')
    history = get_tutor_history(request.user_id, session_id)
    return success({'history': history, 'session_id': session_id})


# ─── TOPICS / KNOWLEDGE BASE ──────────────────────────────────────────────────

@app.route('/api/topics', methods=['GET'])
@optional_auth
def list_topics():
    category = request.args.get('category')
    difficulty = request.args.get('difficulty')
    topics = get_topics(category, difficulty)
    return success({'topics': topics, 'count': len(topics)})


@app.route('/api/topics/<int:topic_id>', methods=['GET'])
@optional_auth
def get_topic(topic_id):
    topic = get_topic_by_id(topic_id)
    if not topic:
        return error('Topic not found', 404)
    lang = request.args.get('lang', 'en')
    if lang != 'en':
        topic['content'] = translate_civic_content(topic['content'], lang)
    return success(topic)


# ─── TRANSLATION ROUTE ────────────────────────────────────────────────────────

@app.route('/api/translate', methods=['POST'])
@optional_auth
def translate():
    data = request.get_json() or {}
    text = data.get('text', '')
    target = data.get('target_language', 'hi')
    source = data.get('source_language', 'en')

    if not text:
        return error('Text required')

    result = call_sarvam_ai(text, source, target)
    return success(result)


@app.route('/api/translate/languages', methods=['GET'])
def get_languages():
    return success({'languages': [
        {'code': 'en', 'name': 'English'},
        {'code': 'hi', 'name': 'Hindi'},
        {'code': 'ta', 'name': 'Tamil'},
        {'code': 'te', 'name': 'Telugu'},
        {'code': 'kn', 'name': 'Kannada'},
        {'code': 'ml', 'name': 'Malayalam'},
        {'code': 'mr', 'name': 'Marathi'},
        {'code': 'bn', 'name': 'Bengali'},
        {'code': 'gu', 'name': 'Gujarati'},
        {'code': 'pa', 'name': 'Punjabi'},
        {'code': 'or', 'name': 'Odia'},
        {'code': 'as', 'name': 'Assamese'},
    ]})


# ─── DASHBOARD ROUTES ─────────────────────────────────────────────────────────

@app.route('/api/dashboard/stats', methods=['GET'])
def platform_stats():
    stats = get_platform_stats()
    return success(stats)


@app.route('/api/dashboard/leaderboard', methods=['GET'])
def leaderboard():
    limit = min(int(request.args.get('limit', 10)), 50)
    leaders = get_leaderboard(limit)
    return success({'leaderboard': leaders, 'count': len(leaders)})


@app.route('/api/dashboard/my-stats', methods=['GET'])
@require_auth
def my_stats():
    user = get_user_by_id(request.user_id)
    history = get_user_quiz_history(request.user_id)

    avg_score = 0
    if history:
        avg_score = round(sum(h['score_percent'] for h in history) / len(history), 1)

    return success({
        'user': {
            'username': user['username'],
            'xp_points': user['xp_points'],
            'preferred_language': user['preferred_language']
        },
        'quiz_sessions': len(history),
        'average_score': avg_score,
        'recent_quizzes': history[:5]
    })


# ─── MAIN ─────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    print("=" * 55)
    print("  CivicIQ Platform - Backend Server")
    print("=" * 55)
    
    # Initialize DB
    init_db()
    
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV', 'development') == 'development'
    
    print(f"\n  API running at: http://localhost:{port}/api")
    print(f"  Frontend at:   http://localhost:{port}/")
    print(f"  Mode:          {'Development' if debug else 'Production'}")
    print("=" * 55 + "\n")
    
    app.run(host='0.0.0.0', port=port, debug=debug)
