"""
CivicIQ AI Engine
─────────────────
Handles:
  1. NLP Civic Tutor  - rule-based + pattern matching (offline; plug Sarvam AI in production)
  2. News Summarizer  - extractive summarization
  3. Quiz Generator   - dynamic question creation from news/bills
  4. Policy Simulator - parameter-based outcome engine
  5. Sarvam AI Hook   - multilingual translation wrapper

In production:
  - Replace civic_tutor_respond() with Sarvam AI API call
  - Replace summarize_news() with a transformer model or Sarvam AI
"""

import re
import json
import random
from datetime import datetime

# ─── CIVIC KNOWLEDGE BASE (offline NLP backbone) ─────────────────────────────

CIVIC_KB = {
    # Constitutional topics
    "constitution": {
        "keywords": ["constitution", "fundamental rights", "preamble", "article", "amendment", "directive principles", "dpsp"],
        "response": """📜 **Indian Constitution Basics**

The Indian Constitution is the world's longest written constitution (448 articles + 12 schedules).

🔑 **Key Structures:**
• **Preamble** — Declares India as Sovereign, Socialist, Secular, Democratic Republic
• **Fundamental Rights** (Part III) — 6 rights guaranteed to ALL citizens
• **Directive Principles** (Part IV) — Guidelines for the state (not enforceable in court)
• **Fundamental Duties** (Part IVA) — 11 duties of every citizen

📅 **Important Dates:**
• Adopted: 26 November 1949
• Came into effect: 26 January 1950 (Republic Day)

💡 *Ask me about specific articles or fundamental rights!*"""
    },
    "parliament": {
        "keywords": ["parliament", "lok sabha", "rajya sabha", "mp", "session", "speaker", "bill", "legislation"],
        "response": """🏛️ **Indian Parliament**

Parliament = Lok Sabha + Rajya Sabha + President

**🟠 Lok Sabha (Lower House)**
• 543 elected + 2 nominated members
• Term: 5 years
• Elected directly by voters (18+ years)

**🔵 Rajya Sabha (Upper House)**
• 250 members (238 elected + 12 nominated)
• Permanent body — 1/3 retire every 2 years
• Represents states and UTs

**📋 How a Bill becomes Law:**
1. Introduction in either house
2. Second reading (debate)
3. Committee stage
4. Third reading (vote)
5. Other house repeats
6. Presidential assent ✅

💡 *Want to know about a specific bill? Ask me!*"""
    },
    "election": {
        "keywords": ["election", "vote", "voting", "eci", "election commission", "constituency", "candidate", "ballot", "evm"],
        "response": """🗳️ **Indian Elections — Explained Simply**

India runs the world's largest democracy!

**📊 Types of Elections:**
• Lok Sabha (National) — every 5 years
• State Assemblies — every 5 years
• Local Bodies — Panchayats & Municipalities

**🏆 Voting System:** First-Past-The-Post (FPTP)
The candidate with the MOST votes wins — even without majority.

**📋 Election Commission of India (ECI)**
• Autonomous constitutional body
• Announces schedules, enforces Model Code of Conduct
• Oversees EVMs and VVPAT machines

**✅ You can vote if:**
• You are 18+ years old
• Your name is in the electoral roll (voter ID)

💡 *Check voter registration at voters.eci.gov.in*"""
    },
    "policy": {
        "keywords": ["policy", "scheme", "government scheme", "welfare", "subsidy", "budget", "gdp", "tax", "gst"],
        "response": """📊 **Government Policies & Schemes**

**Major Active Schemes:**
• 🏠 **PM Awas Yojana** — Housing for all
• 🌾 **PM Kisan** — ₹6000/year to farmers
• 🏥 **Ayushman Bharat** — ₹5 lakh health cover
• 🎓 **PM Scholarship** — For armed forces wards
• 💧 **Jal Jeevan Mission** — Tap water to every home

**How Policies Work:**
1. Ministry drafts the policy
2. Stakeholder consultation
3. Cabinet approval
4. Parliament debate & passage
5. Implementation by state govts

💡 *Ask me about any specific scheme or how to apply!*"""
    },
    "judiciary": {
        "keywords": ["court", "supreme court", "high court", "judge", "justice", "pil", "judgment", "verdict", "bail", "fundamental right"],
        "response": """⚖️ **Indian Judiciary**

India has an independent 3-tier judicial system:

**🏛️ Supreme Court** (New Delhi)
• Apex court — final authority
• Chief Justice + 33 judges
• Original, Appellate & Advisory jurisdiction

**🏢 High Courts** (25 across states)
• Highest court in each state
• Handles appeals from lower courts

**⚡ PIL (Public Interest Litigation)**
Any citizen can file a PIL in High Court or Supreme Court if public interest is at stake — even via a postcard/letter to the court!

**🔑 Landmark Judgments:**
• Kesavananda Bharati (1973) — Basic Structure doctrine
• Vishaka (1997) — Sexual harassment guidelines
• Puttaswamy (2017) — Right to Privacy

💡 *Want to know about a specific judgment? Ask me!*"""
    },
    "rights": {
        "keywords": ["rights", "fundamental rights", "right to equality", "right to freedom", "article 19", "article 21", "article 14"],
        "response": """🛡️ **Your Fundamental Rights (at a glance)**

**1. Right to Equality (Art 14-18)**
• Equal treatment under law
• No discrimination on religion, race, caste, sex, birthplace
• No untouchability (Art 17)

**2. Right to Freedom (Art 19-22)**
• Freedom of speech & expression
• Right to assemble, form associations, move freely
• Right to practice any profession

**3. Right against Exploitation (Art 23-24)**
• Prohibition of human trafficking
• No child labour (under 14 in hazardous industries)

**4. Right to Religion (Art 25-28)**
• Freedom of conscience and religion

**5. Cultural & Educational Rights (Art 29-30)**
• Minorities can protect culture & establish institutions

**6. Right to Constitutional Remedies (Art 32)**
• "Heart and soul of the Constitution" — Dr. B.R. Ambedkar
• You can directly petition the Supreme Court if rights are violated"""
    },
    "federalism": {
        "keywords": ["federal", "state", "centre", "union list", "state list", "concurrent", "governor", "chief minister"],
        "response": """🗺️ **India's Federal Structure**

India is a "quasi-federal" or "federation with unitary bias" state.

**📋 Legislative Lists:**
• **Union List** (97 subjects) — Only Parliament can legislate (e.g., Defence, Foreign Affairs)
• **State List** (66 subjects) — Only states can legislate (e.g., Police, Agriculture)
• **Concurrent List** (47 subjects) — Both can legislate (e.g., Education, Marriage)

**In case of conflict:** Central law prevails on Concurrent List items.

**State Government Structure:**
• Governor (appointed by President)
• Chief Minister + Council of Ministers
• State Legislature (Vidhan Sabha + Vidhan Parishad in some states)"""
    }
}

DEFAULT_RESPONSE = """🤖 **CivicIQ Tutor here!**

I can help you understand:
• 📜 Constitution & Fundamental Rights
• 🏛️ Parliament & Law-making Process  
• 🗳️ Elections & Voting
• 📊 Government Policies & Schemes
• ⚖️ Judiciary & Supreme Court
• 🗺️ Federal Structure of India

**Try asking:**
• "What are my fundamental rights?"
• "How does a bill become a law?"
• "What is RTI?"
• "How do elections work in India?"
• "What is the role of the Supreme Court?"

*Powered by CivicIQ NLP Engine + Sarvam AI (multilingual)*"""

SARVAM_LANGUAGE_MAP = {
    'ta': 'Tamil', 'hi': 'Hindi', 'te': 'Telugu', 'kn': 'Kannada',
    'ml': 'Malayalam', 'mr': 'Marathi', 'bn': 'Bengali', 'gu': 'Gujarati',
    'pa': 'Punjabi', 'or': 'Odia', 'as': 'Assamese', 'en': 'English'
}

SARVAM_TRANSLATIONS = {
    'ta': {
        'greeting': "வணக்கம்! நான் CivicIQ ஆசிரியர். இந்திய அரசியலமைப்பு, தேர்தல்கள், அரசாங்க திட்டங்கள் பற்றி கேளுங்கள்!",
        'constitution': "📜 **இந்திய அரசியலமைப்பு**\n\nவிஷயம் ஆங்கிலத்தில் விளக்கப்பட்டுள்ளது. முழு தமிழ் ஆதரவுக்கு Sarvam AI API இணைக்கவும்.",
    },
    'hi': {
        'greeting': "नमस्ते! मैं CivicIQ ट्यूटर हूँ। भारतीय संविधान, चुनाव, सरकारी योजनाओं के बारे में पूछें!",
    }
}


# ─── 1. CIVIC TUTOR ───────────────────────────────────────────────────────────

def civic_tutor_respond(user_message: str, language: str = 'en', history: list = None) -> str:
    """
    Offline NLP Civic Tutor using keyword matching.
    
    Production upgrade:
        response = call_sarvam_ai(user_message, language, history)
        return response
    """
    msg_lower = user_message.lower().strip()

    # Greeting detection
    if any(w in msg_lower for w in ['hello', 'hi', 'hey', 'vanakkam', 'namaste', 'start']):
        if language in SARVAM_TRANSLATIONS and 'greeting' in SARVAM_TRANSLATIONS[language]:
            return SARVAM_TRANSLATIONS[language]['greeting']
        return "👋 **Welcome to CivicIQ Tutor!**\n\nI'm your AI civic education assistant. Ask me anything about Indian politics, governance, the Constitution, elections, or government policies!\n\n🌐 *Available in 22 Indian languages via Sarvam AI*"

    # RTI specific
    if 'rti' in msg_lower or 'right to information' in msg_lower:
        return """📋 **Right to Information (RTI) Act, 2005**

The RTI Act gives every Indian citizen the right to request information from any public authority.

**🔑 Key Points:**
• Any citizen can file an RTI application
• Government must respond within **30 days** (48 hours for life/liberty matters)
• Application fee: ₹10 (waived for BPL card holders)
• Can be filed online at **rtionline.gov.in**

**📝 How to file:**
1. Write a simple application stating what info you need
2. Pay ₹10 fee (IPO/DD/online)
3. Address to the Public Information Officer (PIO) of the concerned department
4. Keep a copy for your records

**💪 RTI in action:**
RTI has exposed scams, helped citizens get ration cards, land records, and government scheme benefits.

*"An informed citizen is an empowered citizen"* 🇮🇳"""

    # GST / Tax
    if any(w in msg_lower for w in ['gst', 'goods and services tax', 'tax', 'income tax']):
        return """💰 **Understanding GST (Goods & Services Tax)**

GST replaced 17 different taxes in 2017 — simplifying India's tax structure.

**📊 GST Slabs:**
• 0% — Essential goods (rice, wheat, milk, vegetables)
• 5% — Basic items (packaged food, footwear below ₹1000)
• 12% — Standard goods (computers, processed foods)
• 18% — Most goods & services (electronics, AC restaurants)
• 28% — Luxury & sin goods (cars, tobacco, aerated drinks)

**GST Council:**
• Finance Ministers of Centre + all States
• Decides rates and policies
• A great example of cooperative federalism!

💡 *When you buy something, look at the bill — GST shows up there!*"""

    # Match knowledge base categories
    for category, data in CIVIC_KB.items():
        if any(keyword in msg_lower for keyword in data['keywords']):
            return data['response']

    # Sarvam AI placeholder for non-English
    if language != 'en' and language in SARVAM_TRANSLATIONS:
        lang_name = SARVAM_LANGUAGE_MAP.get(language, language)
        return f"🌐 *[{lang_name} response via Sarvam AI]*\n\nYour question: \"{user_message}\"\n\n*Full multilingual support coming with Sarvam AI integration. Currently responding in English:*\n\n" + DEFAULT_RESPONSE

    return DEFAULT_RESPONSE


# ─── 2. NEWS SUMMARIZER ──────────────────────────────────────────────────────

def summarize_for_genz(title: str, original_content: str, category: str = '') -> str:
    """
    Extractive + template-based news summarization.
    
    Production upgrade: Use Sarvam AI or a transformer model (e.g., BART, mT5).
    """
    category_emojis = {
        'parliament': '🏛️', 'election': '🗳️', 'policy': '📊',
        'judiciary': '⚖️', 'state': '🗺️', 'economy': '💰', 'defense': '🛡️'
    }
    emoji = category_emojis.get(category, '📰')

    # Sentence extraction (simple)
    sentences = re.split(r'(?<=[.!?])\s+', original_content.strip())
    key_sentences = sentences[:3] if len(sentences) >= 3 else sentences

    summary = f"{emoji} **{title}**\n\n"
    summary += "**What happened:** " + (key_sentences[0] if key_sentences else "") + "\n\n"

    if len(key_sentences) > 1:
        summary += "**Why it matters for you:** " + key_sentences[1] + "\n\n"

    summary += "**TL;DR (Too Long; Didn't Read):** "
    words = title.lower()
    if 'parliament' in words or 'bill' in words or 'act' in words:
        summary += "New law being made — this could change rules that affect your daily life! 📋"
    elif 'election' in words or 'vote' in words:
        summary += "Election news — your vote matters and this is how democracy works! 🗳️"
    elif 'court' in words or 'judgment' in words:
        summary += "Court decision — the judiciary just shaped what's legal or illegal in India! ⚖️"
    elif 'tax' in words or 'budget' in words or 'economy' in words:
        summary += "Economic decision — this might affect prices, jobs, or your future! 💰"
    else:
        summary += "Government action affecting Indian citizens — stay informed! 🇮🇳"

    summary += "\n\n*Simplified by CivicIQ AI · Original source verified*"
    return summary


# ─── 3. QUIZ GENERATOR (from news/bills) ─────────────────────────────────────

def generate_quiz_from_news(news_title: str, news_summary: str, category: str) -> dict:
    """
    Generate a quiz question from a news item.
    Rule-based template generation.
    
    Production upgrade: Use LLM to generate contextual MCQ.
    """
    templates = [
        {
            "q": f"Which category does this news belong to: '{news_title[:60]}...'?",
            "options": ["Sports & Entertainment", "Technology", "Politics & Governance", "Science"],
            "correct": "c",
            "exp": f"This news is about {category} which falls under Politics & Governance."
        },
        {
            "q": f"What type of governance body is responsible for: '{news_title[:50]}'?",
            "options": ["State Government only", "Central Government / Parliament", "Judiciary", "Election Commission"],
            "correct": "b",
            "exp": "Parliament and Central Government handle national-level legislative and policy decisions."
        }
    ]

    picked = random.choice(templates)
    return {
        "question_text": picked["q"],
        "option_a": picked["options"][0],
        "option_b": picked["options"][1],
        "option_c": picked["options"][2],
        "option_d": picked["options"][3],
        "correct_option": picked["correct"],
        "explanation": picked["exp"],
        "category": category,
        "difficulty": "easy",
        "source_type": "news_based"
    }


# ─── 4. POLICY SIMULATOR ENGINE ──────────────────────────────────────────────

def compute_simulation_outcome(simulation_id: int, user_params: dict, simulation_data: dict) -> dict:
    """
    Computes policy simulation outcomes based on user parameter sliders.
    Uses weighted scoring model.
    
    simulation_data: dict with 'parameters' and 'outcomes' from DB.
    user_params: dict of {param_id: value}
    """
    outcomes = simulation_data.get('outcomes', {})
    params = simulation_data.get('parameters', [])

    # Compute normalized values (0-1)
    normalized = {}
    for p in params:
        pid = p['id']
        val = user_params.get(pid, p.get('default', 50))
        pmin, pmax = p.get('min', 0), p.get('max', 100)
        normalized[pid] = (val - pmin) / (pmax - pmin) if pmax != pmin else 0.5

    # Determine dominant strategy
    max_key = max(normalized, key=normalized.get)
    max_val = normalized[max_key]

    # Build outcome narrative
    outcome_text = ""
    if max_val > 0.7:
        if max_key in outcomes:
            relevant_key = f"high_{max_key.split('_')[0]}"
            outcome_text = outcomes.get(relevant_key, outcomes.get('balanced', "Moderate impact across all indicators."))
        else:
            outcome_text = outcomes.get('balanced', "Moderate impact across all indicators.")
    else:
        outcome_text = outcomes.get('balanced', "A balanced approach shows moderate improvement in all areas.")

    # Build impact scores
    impact_scores = {}
    for k, v in normalized.items():
        label = k.replace('_', ' ').title()
        impact_scores[label] = round(v * 100, 1)

    # Pros and cons based on skewed allocation
    max_param = max(normalized, key=normalized.get)
    min_param = min(normalized, key=normalized.get)

    return {
        "summary": outcome_text,
        "impact_scores": impact_scores,
        "overall_effectiveness": round(sum(normalized.values()) / len(normalized) * 100, 1),
        "strengths": [f"Strong investment in {max_param.replace('_',' ')} will show visible results in 2-3 years"],
        "weaknesses": [f"Under-investment in {min_param.replace('_',' ')} may create gaps"],
        "recommendation": "Consider a more balanced allocation for sustainable long-term impact.",
        "generated_at": datetime.now().isoformat()
    }


# ─── 5. SARVAM AI INTEGRATION (Production Hook) ──────────────────────────────

def call_sarvam_ai(text: str, source_language: str = 'en', target_language: str = 'ta') -> dict:
    """
    Production hook for Sarvam AI API.
    Docs: https://www.sarvam.ai/apis
    
    In production, install requests and make real API call:
    
    import requests
    headers = {
        "api-subscription-key": os.environ.get("SARVAM_API_KEY"),
        "Content-Type": "application/json"
    }
    payload = {
        "input": text,
        "source_language_code": source_language,
        "target_language_code": target_language,
        "speaker_gender": "Female",
        "mode": "formal",
        "enable_preprocessing": True
    }
    response = requests.post(
        "https://api.sarvam.ai/translate",
        json=payload, headers=headers
    )
    return response.json()
    """
    lang_name = SARVAM_LANGUAGE_MAP.get(target_language, target_language)
    return {
        "status": "demo",
        "translated_text": f"[{lang_name} translation via Sarvam AI — connect API key in .env]",
        "source_language": source_language,
        "target_language": target_language,
        "message": "Set SARVAM_API_KEY in environment to enable full multilingual support"
    }


def translate_civic_content(content: str, target_language: str) -> str:
    """Translate civic content using Sarvam AI."""
    if target_language == 'en':
        return content
    result = call_sarvam_ai(content, 'en', target_language)
    return result.get('translated_text', content)
