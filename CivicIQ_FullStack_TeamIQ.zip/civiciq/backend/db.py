"""
CivicIQ Database Module
Handles SQLite connections, initialization, and all DB queries.
In production: swap sqlite3 for mysql-connector-python with MySQL.
"""

import sqlite3
import os
import json
import hashlib

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'database', 'civiciq.db')
SCHEMA_PATH = os.path.join(os.path.dirname(__file__), '..', 'database', 'schema.sql')
SEED_PATH = os.path.join(os.path.dirname(__file__), '..', 'database', 'seed.sql')


def get_db():
    """Get a database connection with row_factory for dict-like access."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Initialize the database with schema and seed data."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_db()
    cursor = conn.cursor()
    with open(SCHEMA_PATH, 'r') as f:
        cursor.executescript(f.read())
    with open(SEED_PATH, 'r') as f:
        cursor.executescript(f.read())
    conn.commit()
    conn.close()
    print(f"[DB] Initialized at {DB_PATH}")


def hash_password(password: str) -> str:
    return hashlib.md5(password.encode()).hexdigest()


def row_to_dict(row):
    if row is None:
        return None
    return dict(row)


def rows_to_list(rows):
    return [dict(r) for r in rows]


# ─── USER QUERIES ───────────────────────────────────────────

def create_user(username, email, password, role='student', language='en'):
    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO users (username,email,password_hash,role,preferred_language,is_verified) VALUES (?,?,?,?,?,1)",
            (username, email, hash_password(password), role, language)
        )
        conn.commit()
        return True, "User created"
    except sqlite3.IntegrityError as e:
        return False, "Username or email already exists"
    finally:
        conn.close()


def authenticate_user(email, password):
    conn = get_db()
    user = conn.execute(
        "SELECT * FROM users WHERE email=? AND password_hash=?",
        (email, hash_password(password))
    ).fetchone()
    conn.close()
    return row_to_dict(user)


def get_user_by_id(user_id):
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    return row_to_dict(user)


def update_user_xp(user_id, points):
    conn = get_db()
    conn.execute("UPDATE users SET xp_points = xp_points + ? WHERE id=?", (points, user_id))
    conn.commit()
    conn.close()


# ─── NEWS QUERIES ────────────────────────────────────────────

def get_news(category=None, limit=10, offset=0):
    conn = get_db()
    if category and category != 'all':
        rows = conn.execute(
            "SELECT * FROM news_articles WHERE category=? ORDER BY published_at DESC LIMIT ? OFFSET ?",
            (category, limit, offset)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM news_articles ORDER BY published_at DESC LIMIT ? OFFSET ?",
            (limit, offset)
        ).fetchall()
    conn.close()
    return rows_to_list(rows)


def get_news_by_id(news_id):
    conn = get_db()
    row = conn.execute("SELECT * FROM news_articles WHERE id=?", (news_id,)).fetchone()
    conn.close()
    return row_to_dict(row)


# ─── BILLS QUERIES ───────────────────────────────────────────

def get_bills(limit=10):
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM bills ORDER BY passed_date DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    result = rows_to_list(rows)
    for b in result:
        if b.get('impact_areas'):
            try:
                b['impact_areas'] = json.loads(b['impact_areas'])
            except:
                pass
    return result


def get_bill_by_id(bill_id):
    conn = get_db()
    row = conn.execute("SELECT * FROM bills WHERE id=?", (bill_id,)).fetchone()
    conn.close()
    b = row_to_dict(row)
    if b and b.get('impact_areas'):
        try:
            b['impact_areas'] = json.loads(b['impact_areas'])
        except:
            pass
    return b


# ─── QUIZ QUERIES ────────────────────────────────────────────

def get_quiz_questions(category=None, difficulty=None, limit=10):
    conn = get_db()
    query = "SELECT * FROM quiz_questions WHERE 1=1"
    params = []
    if category and category != 'all':
        query += " AND category=?"; params.append(category)
    if difficulty and difficulty != 'all':
        query += " AND difficulty=?"; params.append(difficulty)
    query += " ORDER BY RANDOM() LIMIT ?"
    params.append(limit)
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return rows_to_list(rows)


def save_quiz_session(user_id, category, total, correct, time_sec):
    score = round((correct / total) * 100, 1) if total > 0 else 0
    conn = get_db()
    cur = conn.execute(
        "INSERT INTO quiz_sessions (user_id,category,total_questions,correct_answers,score_percent,time_taken_seconds) VALUES (?,?,?,?,?,?)",
        (user_id, category, total, correct, score, time_sec)
    )
    session_id = cur.lastrowid
    conn.commit()
    conn.close()
    xp = correct * 10
    update_user_xp(user_id, xp)
    return session_id, score, xp


def get_user_quiz_history(user_id):
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM quiz_sessions WHERE user_id=? ORDER BY completed_at DESC LIMIT 20",
        (user_id,)
    ).fetchall()
    conn.close()
    return rows_to_list(rows)


# ─── POLL QUERIES ────────────────────────────────────────────

def get_active_polls():
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM polls WHERE is_active=1 ORDER BY created_at DESC"
    ).fetchall()
    conn.close()
    return rows_to_list(rows)


def get_poll_results(poll_id):
    conn = get_db()
    poll = conn.execute("SELECT * FROM polls WHERE id=?", (poll_id,)).fetchone()
    votes = conn.execute(
        "SELECT selected_option, COUNT(*) as count FROM poll_votes WHERE poll_id=? GROUP BY selected_option",
        (poll_id,)
    ).fetchall()
    total = conn.execute(
        "SELECT COUNT(*) as total FROM poll_votes WHERE poll_id=?", (poll_id,)
    ).fetchone()['total']
    conn.close()
    if not poll:
        return None
    result = row_to_dict(poll)
    vote_map = {r['selected_option']: r['count'] for r in votes}
    result['votes'] = vote_map
    result['total_votes'] = total
    return result


def cast_poll_vote(poll_id, user_id, option):
    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO poll_votes (poll_id, user_id, selected_option) VALUES (?,?,?)",
            (poll_id, user_id, option)
        )
        conn.commit()
        conn.close()
        return True, "Vote recorded"
    except sqlite3.IntegrityError:
        conn.close()
        return False, "Already voted on this poll"


# ─── SIMULATION QUERIES ──────────────────────────────────────

def get_simulations():
    conn = get_db()
    rows = conn.execute("SELECT * FROM simulations ORDER BY policy_area").fetchall()
    conn.close()
    result = rows_to_list(rows)
    for s in result:
        for key in ('parameters', 'outcomes'):
            if s.get(key):
                try:
                    s[key] = json.loads(s[key])
                except:
                    pass
    return result


def get_simulation_by_id(sim_id):
    conn = get_db()
    row = conn.execute("SELECT * FROM simulations WHERE id=?", (sim_id,)).fetchone()
    conn.close()
    s = row_to_dict(row)
    if s:
        for key in ('parameters', 'outcomes'):
            if s.get(key):
                try:
                    s[key] = json.loads(s[key])
                except:
                    pass
    return s


def save_simulation_run(sim_id, user_id, input_params, outcome):
    conn = get_db()
    conn.execute(
        "INSERT INTO simulation_runs (simulation_id,user_id,input_params,generated_outcome) VALUES (?,?,?,?)",
        (sim_id, user_id, json.dumps(input_params), json.dumps(outcome))
    )
    conn.commit()
    conn.close()


# ─── TOPIC / KNOWLEDGE BASE QUERIES ─────────────────────────

def get_topics(category=None, difficulty=None):
    conn = get_db()
    query = "SELECT * FROM topics WHERE 1=1"
    params = []
    if category:
        query += " AND category=?"; params.append(category)
    if difficulty:
        query += " AND difficulty=?"; params.append(difficulty)
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return rows_to_list(rows)


def get_topic_by_id(topic_id):
    conn = get_db()
    conn.execute("UPDATE topics SET view_count = view_count + 1 WHERE id=?", (topic_id,))
    conn.commit()
    row = conn.execute("SELECT * FROM topics WHERE id=?", (topic_id,)).fetchone()
    conn.close()
    return row_to_dict(row)


# ─── TUTOR QUERIES ───────────────────────────────────────────

def save_tutor_message(user_id, session_id, role, message, language='en'):
    conn = get_db()
    conn.execute(
        "INSERT INTO tutor_chats (user_id,session_id,message_role,message_text,language) VALUES (?,?,?,?,?)",
        (user_id, session_id, role, message, language)
    )
    conn.commit()
    conn.close()


def get_tutor_history(user_id, session_id):
    conn = get_db()
    rows = conn.execute(
        "SELECT message_role, message_text FROM tutor_chats WHERE user_id=? AND session_id=? ORDER BY created_at",
        (user_id, session_id)
    ).fetchall()
    conn.close()
    return rows_to_list(rows)


# ─── DASHBOARD / ANALYTICS ───────────────────────────────────

def get_platform_stats():
    conn = get_db()
    stats = {
        'total_users': conn.execute("SELECT COUNT(*) as c FROM users").fetchone()['c'],
        'total_quizzes': conn.execute("SELECT COUNT(*) as c FROM quiz_sessions").fetchone()['c'],
        'total_polls': conn.execute("SELECT COUNT(*) as c FROM poll_votes").fetchone()['c'],
        'total_news': conn.execute("SELECT COUNT(*) as c FROM news_articles").fetchone()['c'],
        'total_bills': conn.execute("SELECT COUNT(*) as c FROM bills").fetchone()['c'],
    }
    conn.close()
    return stats


def get_leaderboard(limit=10):
    conn = get_db()
    rows = conn.execute(
        "SELECT username, xp_points, role FROM users ORDER BY xp_points DESC LIMIT ?",
        (limit,)
    ).fetchall()
    conn.close()
    return rows_to_list(rows)
