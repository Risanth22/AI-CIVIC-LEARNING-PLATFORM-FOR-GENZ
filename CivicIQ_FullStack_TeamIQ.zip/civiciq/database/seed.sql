-- ============================================================
-- CivicIQ Platform - Seed Data
-- ============================================================

-- ADMIN USER (password: Admin@123)
INSERT OR IGNORE INTO users (username, email, password_hash, role, xp_points, is_verified)
VALUES ('admin', 'admin@civiciq.in', 'e99a18c428cb38d5f260853678922e03', 'admin', 9999, 1);

-- SAMPLE STUDENT (password: Student@123)
INSERT OR IGNORE INTO users (username, email, password_hash, role, xp_points, is_verified, preferred_language)
VALUES ('genz_voter', 'genz@civiciq.in', '5e8c6f1fce39c43f01a4b1b1c3e6da13', 'student', 450, 1, 'ta');

-- SAMPLE EDUCATOR (password: Edu@123)
INSERT OR IGNORE INTO users (username, email, password_hash, role, is_verified)
VALUES ('prof_sharma', 'sharma@civiciq.in', 'b14a7b8059d9c055954c92674ce60032', 'educator', 1);

INSERT OR IGNORE INTO educators (user_id, full_name, institution, expertise, is_approved)
VALUES (3, 'Prof. Rajesh Sharma', 'IIT Madras', 'Constitutional Law, Public Policy', 1);

-- CIVIC TOPICS (Knowledge Base)
INSERT OR IGNORE INTO topics (title, category, content, difficulty, language, created_by) VALUES
('What is the Constitution of India?', 'constitution',
 'The Constitution of India is the supreme law of India. Adopted on 26 November 1949, it came into effect on 26 January 1950. It lays down the framework defining fundamental political principles, establishes the structure, procedures, powers, and duties of government institutions, and sets out fundamental rights and directive principles.',
 'beginner', 'en', 1),

('How does the Indian Parliament Work?', 'governance',
 'The Parliament of India is the supreme legislative body. It consists of the President of India and the two Houses: Lok Sabha (House of the People) and Rajya Sabha (Council of States). The Lok Sabha has 545 members, while the Rajya Sabha has 250 members. A bill must pass both houses and receive Presidential assent to become law.',
 'beginner', 'en', 1),

('Understanding Elections in India', 'election',
 'India conducts the world''s largest democratic elections. The Election Commission of India (ECI) is an autonomous constitutional authority responsible for administering election processes. India uses the First Past The Post (FPTP) system for Lok Sabha and State Assembly elections.',
 'beginner', 'en', 1),

('Fundamental Rights of Indian Citizens', 'constitution',
 'The Constitution guarantees six fundamental rights: (1) Right to Equality (Articles 14-18), (2) Right to Freedom (Articles 19-22), (3) Right against Exploitation (Articles 23-24), (4) Right to Freedom of Religion (Articles 25-28), (5) Cultural and Educational Rights (Articles 29-30), (6) Right to Constitutional Remedies (Article 32).',
 'intermediate', 'en', 1),

('How a Bill Becomes a Law', 'governance',
 'A bill can be introduced in either house of Parliament. It goes through three readings, a committee stage, and voting. If passed, it goes to the other house and repeats the process. If both houses pass it, it goes to the President for assent. After Presidential assent, it becomes an Act of Parliament.',
 'beginner', 'en', 1);

-- SAMPLE NEWS
INSERT OR IGNORE INTO news_articles (original_title, original_content, simplified_summary, source_name, source_url, category, published_at, is_verified) VALUES
('Parliament passes Digital Personal Data Protection Amendment Bill',
 'The Parliament of India on Thursday passed the Digital Personal Data Protection Amendment Bill...',
 'India just got a new law to protect your personal data online! 🔐 This means companies must now ask your permission before using your information. If they misuse it, they face huge fines. This directly affects how apps like Instagram and Zomato handle your data.',
 'PRS Legislative Research', 'https://prsindia.org', 'parliament', datetime('now', '-2 days'), 1),

('Election Commission announces schedule for 5 state assembly elections',
 'The Election Commission of India on Monday announced the schedule for assembly elections in five states...',
 '🗳️ Elections are coming in 5 states! The dates have been announced. This means voting machines are being prepared, political parties will start their campaigns, and the Model Code of Conduct kicks in — meaning no new government schemes can be announced during this period.',
 'Election Commission of India', 'https://eci.gov.in', 'election', datetime('now', '-1 day'), 1),

('Supreme Court rules on Right to Privacy in digital age',
 'A constitution bench of the Supreme Court delivered a landmark judgment affirming that right to privacy...',
 '⚖️ Big news from the Supreme Court! The judges ruled that your right to privacy also covers your digital life. This means the government and private companies cannot secretly monitor your online activity without legal justification. This builds on the landmark 2017 Puttaswamy judgment.',
 'Supreme Court of India', 'https://sci.gov.in', 'judiciary', datetime('now', '-3 days'), 1);

-- BILLS
INSERT OR IGNORE INTO bills (bill_number, bill_name, passed_date, house, ministry, simplified_explanation, impact_areas, status) VALUES
('Bill No. 12 of 2024', 'The Digital Personal Data Protection (Amendment) Act, 2024',
 '2024-08-05', 'Both', 'Ministry of Electronics and IT',
 'This law protects YOUR data. Companies must tell you exactly what data they collect and why. You can ask them to delete your data. If they misuse it, fines can go up to ₹250 crore. Think of it as a "data rights" law for the internet age.',
 '["technology","privacy","digital_economy","consumer_rights"]', 'passed'),

('Bill No. 8 of 2024', 'The Bharatiya Nyaya Sanhita (Second Amendment) Act, 2024',
 '2024-07-15', 'Lok Sabha', 'Ministry of Home Affairs',
 'India''s criminal law got updated! The old British-era laws (IPC, CrPC, Evidence Act) have been replaced with new Indian laws. Key changes: faster trials, better victim rights, and new provisions for organized crime and terrorism.',
 '["law","justice","criminal_reform","governance"]', 'passed');

-- QUIZ QUESTIONS
INSERT OR IGNORE INTO quiz_questions (question_text, option_a, option_b, option_c, option_d, correct_option, explanation, category, difficulty) VALUES
('How many seats are there in the Lok Sabha?',
 '250', '545', '552', '543',
 'b', 'The Lok Sabha has 545 seats — 543 elected members and 2 nominated by the President (Anglo-Indian community, though this provision was removed in 2020).', 'governance', 'easy'),

('Which article of the Indian Constitution abolishes untouchability?',
 'Article 14', 'Article 17', 'Article 21', 'Article 25',
 'b', 'Article 17 of the Constitution abolishes untouchability and forbids its practice in any form.', 'constitution', 'medium'),

('The concept of "Basic Structure" of the Constitution was established in which landmark case?',
 'Golaknath case', 'Minerva Mills case', 'Kesavananda Bharati case', 'Maneka Gandhi case',
 'c', 'The Kesavananda Bharati vs State of Kerala (1973) case established the Basic Structure doctrine — Parliament cannot amend the Constitution to damage its basic features.', 'constitution', 'hard'),

('Which body conducts Lok Sabha elections in India?',
 'Supreme Court', 'Parliament', 'Election Commission of India', 'President of India',
 'c', 'The Election Commission of India (ECI) is an autonomous constitutional body that administers election processes in India.', 'election', 'easy'),

('What is the minimum age to vote in Indian elections?',
 '16 years', '18 years', '21 years', '25 years',
 'b', 'The 61st Constitutional Amendment (1988) lowered the voting age from 21 to 18 years.', 'election', 'easy'),

('The Preamble of the Constitution declares India to be:',
 'A Federal Democratic Republic', 'A Sovereign Socialist Secular Democratic Republic', 'A Secular Federal State', 'A Parliamentary Democracy',
 'b', 'The Preamble declares India to be a "Sovereign Socialist Secular Democratic Republic" with justice, liberty, equality, and fraternity as its ideals.', 'constitution', 'medium'),

('Which house of Parliament is known as the "Upper House"?',
 'Lok Sabha', 'Rajya Sabha', 'Vidhan Sabha', 'Vidhan Parishad',
 'b', 'Rajya Sabha is the Upper House (Council of States). It has 250 members and represents Indian states and union territories.', 'governance', 'easy'),

('RTI Act (Right to Information) was passed in which year?',
 '2002', '2003', '2005', '2007',
 'c', 'The Right to Information Act was passed in 2005. It empowers citizens to request information from public authorities within 30 days.', 'policy', 'medium');

-- POLLS
INSERT OR IGNORE INTO polls (question, option_a, option_b, option_c, option_d, category, is_active, created_by) VALUES
('Should voting age be lowered to 16 in India?',
 'Yes, 16-year-olds are politically aware', 'No, 18 is the right age', 'Only for local elections', 'Need more civic education first',
 'election', 1, 1),

('Which issue should be the top government priority in the next budget?',
 'Education & Skill Development', 'Healthcare & Hospitals', 'Climate Change & Clean Energy', 'Job Creation & Employment',
 'policy', 1, 1),

('Should social media platforms be regulated by the government?',
 'Yes, strict regulation needed', 'Light-touch regulation only', 'No, let platforms self-regulate', 'Need a new independent body',
 'policy', 1, 1);

-- POLICY SIMULATIONS
INSERT OR IGNORE INTO simulations (title, description, policy_area, parameters, outcomes) VALUES
('Education Budget Simulator',
 'You are the Finance Minister. Decide how to allocate the education budget. See how your choices affect literacy rates, employment, and social equality.',
 'education',
 '[
   {"id": "primary_spend", "label": "Primary Education Investment", "min": 0, "max": 100, "default": 40, "unit": "% of budget"},
   {"id": "digital_infra", "label": "Digital Infrastructure", "min": 0, "max": 100, "default": 30, "unit": "% of budget"},
   {"id": "teacher_training", "label": "Teacher Training Programs", "min": 0, "max": 100, "default": 30, "unit": "% of budget"}
 ]',
 '{
   "high_primary": "Literacy rates rise by 15% in 5 years. Rural dropout rates fall by 20%. Long-term GDP contribution increases.",
   "high_digital": "Urban students gain tech skills. Digital divide may widen without physical infrastructure. Startup ecosystem strengthens.",
   "high_teacher": "Teaching quality improves across all levels. Student engagement rises by 25%. Systematic reform takes 3-5 years to show results.",
   "balanced": "Moderate improvement across all indicators. Most sustainable long-term approach."
 }'),

('Carbon Tax Policy Simulator',
 'Implement a carbon tax policy and watch its impact on industries, environment, and public cost of living.',
 'environment',
 '[
   {"id": "tax_rate", "label": "Carbon Tax Rate", "min": 0, "max": 100, "default": 30, "unit": "₹ per tonne CO₂"},
   {"id": "green_rebate", "label": "Green Energy Subsidies", "min": 0, "max": 100, "default": 50, "unit": "% rebate"},
   {"id": "industry_phase", "label": "Industry Phase-in Period", "min": 1, "max": 10, "default": 5, "unit": "years"}
 ]',
 '{
   "high_tax": "CO₂ emissions drop 30% in 5 years. Fuel prices rise by 12%. Industries accelerate green transition. Air quality improves significantly.",
   "high_rebate": "Renewable energy adoption doubles. Government revenue decreases. Long-term economic gains in green jobs.",
   "long_phase": "Less economic disruption. Slower environmental improvement. Industries have time to adapt. Public acceptance higher."
 }');
