-- ============================================================
-- CivicIQ – MySQL Database Schema
-- Team IQ | V.S.B Engineering College, Karur
-- ============================================================
CREATE DATABASE IF NOT EXISTS civiciq CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE civiciq;

CREATE TABLE users (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role          ENUM('STUDENT','EDUCATOR','ADMIN') DEFAULT 'STUDENT',
    language      VARCHAR(20) DEFAULT 'en',
    is_verified   BOOLEAN DEFAULT FALSE,
    avatar_url    VARCHAR(255),
    xp_points     INT DEFAULT 0,
    streak_days   INT DEFAULT 0,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE civic_topics (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    title       VARCHAR(200) NOT NULL,
    category    ENUM('CONSTITUTION','PARLIAMENT','ELECTIONS','JUDICIARY','LOCAL_GOVT','POLICY','RIGHTS') NOT NULL,
    content     TEXT NOT NULL,
    summary     TEXT,
    language    VARCHAR(20) DEFAULT 'en',
    created_by  BIGINT,
    is_verified BOOLEAN DEFAULT FALSE,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE news_articles (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    title         VARCHAR(500) NOT NULL,
    source        VARCHAR(150),
    original_url  VARCHAR(500),
    raw_content   TEXT,
    ai_summary    TEXT,
    category      VARCHAR(100),
    language      VARCHAR(20) DEFAULT 'en',
    published_at  TIMESTAMP,
    fetched_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_verified   BOOLEAN DEFAULT TRUE
);

CREATE TABLE tutor_sessions (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT NOT NULL,
    session_key VARCHAR(64) UNIQUE,
    language    VARCHAR(20) DEFAULT 'en',
    started_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE tutor_messages (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    session_id  BIGINT NOT NULL,
    role        ENUM('user','assistant') NOT NULL,
    content     TEXT NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES tutor_sessions(id)
);

CREATE TABLE quizzes (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    title       VARCHAR(200) NOT NULL,
    category    VARCHAR(100),
    source_type ENUM('NEWS','BILL','CONSTITUTION','GENERAL') DEFAULT 'GENERAL',
    source_id   BIGINT,
    generated   BOOLEAN DEFAULT TRUE,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE quiz_questions (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    quiz_id     BIGINT NOT NULL,
    question    TEXT NOT NULL,
    option_a    VARCHAR(300) NOT NULL,
    option_b    VARCHAR(300) NOT NULL,
    option_c    VARCHAR(300) NOT NULL,
    option_d    VARCHAR(300) NOT NULL,
    correct_opt ENUM('A','B','C','D') NOT NULL,
    explanation TEXT,
    difficulty  ENUM('EASY','MEDIUM','HARD') DEFAULT 'MEDIUM',
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id)
);

CREATE TABLE quiz_attempts (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id      BIGINT NOT NULL,
    quiz_id      BIGINT NOT NULL,
    score        INT DEFAULT 0,
    total        INT DEFAULT 0,
    time_taken   INT,
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id)
);

CREATE TABLE polls (
    id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    question   TEXT NOT NULL,
    category   VARCHAR(100),
    created_by BIGINT,
    expires_at TIMESTAMP,
    is_active  BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE poll_options (
    id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    poll_id BIGINT NOT NULL,
    label   VARCHAR(300) NOT NULL,
    FOREIGN KEY (poll_id) REFERENCES polls(id)
);

CREATE TABLE poll_votes (
    id        BIGINT AUTO_INCREMENT PRIMARY KEY,
    poll_id   BIGINT NOT NULL,
    option_id BIGINT NOT NULL,
    user_id   BIGINT NOT NULL,
    voted_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_user_poll (user_id, poll_id),
    FOREIGN KEY (poll_id) REFERENCES polls(id),
    FOREIGN KEY (option_id) REFERENCES poll_options(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE policy_scenarios (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    title       VARCHAR(200) NOT NULL,
    description TEXT,
    domain      ENUM('ECONOMY','EDUCATION','HEALTH','ENVIRONMENT','DEFENCE','SOCIAL') NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE policy_options (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    scenario_id BIGINT NOT NULL,
    label       VARCHAR(200) NOT NULL,
    impact_json JSON,
    FOREIGN KEY (scenario_id) REFERENCES policy_scenarios(id)
);

CREATE TABLE policy_simulations (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT NOT NULL,
    scenario_id BIGINT NOT NULL,
    option_id   BIGINT NOT NULL,
    result_json JSON,
    run_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (scenario_id) REFERENCES policy_scenarios(id),
    FOREIGN KEY (option_id) REFERENCES policy_options(id)
);

CREATE TABLE bills (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    bill_number VARCHAR(50),
    title       VARCHAR(300) NOT NULL,
    passed_date DATE,
    ministry    VARCHAR(200),
    raw_text    TEXT,
    ai_summary  TEXT,
    key_points  JSON,
    source_url  VARCHAR(500),
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE lessons (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    title       VARCHAR(200) NOT NULL,
    educator_id BIGINT NOT NULL,
    topic_id    BIGINT,
    content     TEXT NOT NULL,
    video_url   VARCHAR(500),
    is_approved BOOLEAN DEFAULT FALSE,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (educator_id) REFERENCES users(id),
    FOREIGN KEY (topic_id) REFERENCES civic_topics(id)
);

CREATE TABLE user_progress (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id      BIGINT NOT NULL UNIQUE,
    quizzes_done INT DEFAULT 0,
    polls_voted  INT DEFAULT 0,
    lessons_read INT DEFAULT 0,
    sims_run     INT DEFAULT 0,
    total_xp     INT DEFAULT 0,
    level        INT DEFAULT 1,
    badges_json  JSON,
    updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Seed Data
INSERT INTO users (name, email, password_hash, role, is_verified) VALUES
('Admin','admin@civiciq.in','$2a$10$hashed','ADMIN',TRUE),
('Student Demo','student@civiciq.in','$2a$10$hashed','STUDENT',TRUE),
('Dr. Educator','educator@civiciq.in','$2a$10$hashed','EDUCATOR',TRUE);

INSERT INTO civic_topics (title,category,content,summary,created_by,is_verified) VALUES
('What is the Indian Parliament?','PARLIAMENT','The Indian Parliament is the supreme legislative body consisting of Lok Sabha, Rajya Sabha, and the President.','Parliament = Lok Sabha + Rajya Sabha + President.',1,TRUE),
('How Elections Work in India','ELECTIONS','General elections are conducted every 5 years by the Election Commission of India using FPTP system.','Elections every 5 years managed by ECI.',1,TRUE),
('Fundamental Rights of India','RIGHTS','Part III (Articles 12-35) guarantees six fundamental rights: Equality, Freedom, Against Exploitation, Religion, Cultural/Educational, Constitutional Remedies.','Six fundamental rights under Part III of the Constitution.',1,TRUE);

INSERT INTO polls (question,category,created_by,is_active) VALUES
('Should voting age be lowered to 16 in India?','ELECTIONS',1,TRUE),
('Which area needs most government focus in 2025?','POLICY',1,TRUE);

INSERT INTO poll_options (poll_id,label) VALUES
(1,'Yes, 16-year-olds are mature enough'),(1,'No, keep it at 18'),(1,'Yes, but with civic education first'),
(2,'Education'),(2,'Healthcare'),(2,'Employment / Economy'),(2,'Climate & Environment');

INSERT INTO policy_scenarios (title,description,domain) VALUES
('National Education Budget','The government plans to revise the national education budget. Which approach?','EDUCATION'),
('Climate Action Plan','India needs a new climate policy commitment. Which do you prefer?','ENVIRONMENT');

INSERT INTO policy_options (scenario_id,label,impact_json) VALUES
(1,'Increase budget by 50%','{"economy":-2,"education":5,"health":1,"environment":0,"social":3}'),
(1,'Maintain current budget','{"economy":0,"education":0,"health":0,"environment":0,"social":0}'),
(1,'Redirect funds to tech education','{"economy":3,"education":3,"health":0,"environment":0,"social":1}'),
(2,'Carbon neutral by 2040','{"economy":-1,"education":0,"health":3,"environment":5,"social":2}'),
(2,'Gradual transition by 2060','{"economy":1,"education":0,"health":1,"environment":2,"social":1}'),
(2,'Prioritize economic growth first','{"economy":4,"education":0,"health":-1,"environment":-3,"social":0}');
