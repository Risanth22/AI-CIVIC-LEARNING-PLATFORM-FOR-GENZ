"""
CivicIQ AI Service - FastAPI
NLP Civic Tutor | News Summarizer | Quiz Generator | Policy Simulator | Sarvam AI
Team IQ | V.S.B Engineering College, Karur
"""
import os, nltk, requests
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
from dotenv import load_dotenv

load_dotenv()
nltk.download('punkt', quiet=True)
nltk.download('stopwords', quiet=True)

app = FastAPI(title="CivicIQ AI Service", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

NEWS_API_KEY   = os.getenv("NEWS_API_KEY", "")
SARVAM_API_KEY = os.getenv("SARVAM_API_KEY", "")

# ── Civic Knowledge Base ──────────────────────────────────────────────────────
CIVIC_KB = {
    "parliament": "The Indian Parliament has two houses: Lok Sabha (543 elected seats) and Rajya Sabha (245 seats). Laws must pass both houses and receive Presidential assent to become law.",
    "elections": "Indian General Elections occur every 5 years, managed by the Election Commission of India using First-Past-The-Post (FPTP) voting. Citizens aged 18+ are eligible to vote.",
    "constitution": "The Indian Constitution came into effect on January 26, 1950. It has 448 Articles, 12 Schedules, and 25 Parts. Dr. B.R. Ambedkar is its principal architect.",
    "fundamental rights": "Part III (Articles 12-35) guarantees six fundamental rights: Equality, Freedom, Against Exploitation, Religion, Cultural/Educational Rights, and Constitutional Remedies.",
    "directive principles": "Part IV (Articles 36-51) contains Directive Principles - non-justiciable guidelines for the government to create a welfare society.",
    "supreme court": "The Supreme Court of India is the apex judicial body with original, appellate, and advisory jurisdiction. The Chief Justice of India heads it.",
    "panchayati raj": "The 73rd Amendment (1992) gave constitutional status to Panchayati Raj Institutions for local self-governance in rural India.",
    "gst": "Goods and Services Tax (GST), introduced July 1, 2017, is a unified indirect tax - 'One Nation, One Tax' replacing multiple indirect taxes.",
    "rti": "Right to Information Act 2005 allows citizens to request information from public authorities within 30 days, promoting government transparency.",
    "president": "The President of India is the constitutional head of state, elected indirectly by elected members of Parliament and State Legislatures for a 5-year term.",
    "prime minister": "The Prime Minister is the head of government and leads the Council of Ministers. The PM is appointed by the President and must command majority in Lok Sabha.",
    "lok sabha": "Lok Sabha is the lower house of Parliament with 543 seats. Members are directly elected by citizens for 5-year terms.",
    "rajya sabha": "Rajya Sabha is the upper house with 245 members. Members are elected by state legislatures and serve 6-year terms.",
}

# ── Pydantic Models ───────────────────────────────────────────────────────────
class TutorRequest(BaseModel):
    question: str
    language: str = "en"

class SummarizeRequest(BaseModel):
    text: str
    language: str = "en"
    max_sentences: int = 3

class QuizGenRequest(BaseModel):
    topic: str
    num_questions: int = 5
    difficulty: str = "MEDIUM"

class PolicySimRequest(BaseModel):
    option_label: str
    impact_json: dict

class TranslateRequest(BaseModel):
    text: str
    target_language: str

class BillRequest(BaseModel):
    title: str
    raw_text: str
    language: str = "en"

# ── Helpers ───────────────────────────────────────────────────────────────────
def translate_via_sarvam(text: str, target_lang: str) -> Optional[str]:
    lang_map = {"hi":"hi-IN","ta":"ta-IN","te":"te-IN","kn":"kn-IN",
                "ml":"ml-IN","mr":"mr-IN","bn":"bn-IN","gu":"gu-IN","pa":"pa-IN"}
    target = lang_map.get(target_lang)
    if not target or not SARVAM_API_KEY:
        return None
    try:
        r = requests.post("https://api.sarvam.ai/translate",
            headers={"api-subscription-key": SARVAM_API_KEY, "Content-Type": "application/json"},
            json={"input": text, "source_language_code": "en-IN",
                  "target_language_code": target, "model": "mayura:v1"}, timeout=10)
        return r.json().get("translated_text") if r.status_code == 200 else None
    except Exception:
        return None

def extractive_summary(text: str, n: int = 3) -> str:
    sentences = nltk.sent_tokenize(text)
    if len(sentences) <= n:
        return text
    stopwords = set(nltk.corpus.stopwords.words('english'))
    words = [w.lower() for w in nltk.word_tokenize(text) if w.isalpha() and w.lower() not in stopwords]
    freq = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1
    scored = [(sum(freq.get(w.lower(), 0) for w in nltk.word_tokenize(s) if w.isalpha()), s) for s in sentences]
    top = sorted(scored, reverse=True)[:n]
    return " ".join(s for _, s in sorted(top, key=lambda x: sentences.index(x[1])))

# ── Endpoints ─────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    return {"status": "ok", "service": "CivicIQ AI Service", "version": "1.0.0"}

@app.post("/api/tutor/ask")
def ask_tutor(req: TutorRequest):
    q = req.question.lower()
    answer = next((v for k, v in CIVIC_KB.items() if k in q), None)
    if not answer:
        civic_terms = ["india","parliament","government","vote","election","law","court",
                       "minister","president","bill","constitution","rights","policy"]
        matched = [t for t in civic_terms if t in q]
        answer = (
            f"Great question about {'& '.join(matched) if matched else 'civic topics'}! "
            "In India's parliamentary democracy, elected representatives make laws, "
            "the executive implements them, and an independent judiciary interprets them. "
            "Ask me about Parliament, Elections, Constitution, Fundamental Rights, GST, RTI, "
            "Supreme Court, Panchayati Raj, or any other governance topic!"
        )
    if req.language != "en":
        translated = translate_via_sarvam(answer, req.language)
        if translated:
            answer = translated
    return {"question": req.question, "answer": answer, "language": req.language,
            "sources": ["prsindia.org", "eci.gov.in", "Constitution of India"]}

@app.post("/api/news/summarize")
def summarize(req: SummarizeRequest):
    summary = extractive_summary(req.text, req.max_sentences)
    if req.language != "en":
        t = translate_via_sarvam(summary, req.language)
        if t:
            summary = t
    return {"summary": summary, "language": req.language,
            "original_length": len(req.text), "summary_length": len(summary)}

@app.get("/api/news/fetch")
def fetch_news(category: str = "politics", country: str = "in"):
    if not NEWS_API_KEY:
        return {"articles": _demo_news(), "demo": True}
    try:
        r = requests.get("https://newsapi.org/v2/top-headlines",
            params={"category": category, "country": country, "pageSize": 10, "apiKey": NEWS_API_KEY},
            timeout=10)
        articles = r.json().get("articles", [])
        result = []
        for a in articles:
            content = a.get("content") or a.get("description") or ""
            summary = extractive_summary(content, 2)
            result.append({"title": a.get("title"), "source": a.get("source",{}).get("name"),
                           "url": a.get("url"), "summary": summary, "publishedAt": a.get("publishedAt")})
        return {"articles": result, "total": len(result)}
    except Exception:
        return {"articles": _demo_news(), "demo": True}

def _demo_news():
    return [
        {"title":"Parliament passes Digital Personal Data Protection Bill",
         "source":"The Hindu","summary":"Parliament passed the DPDP Bill protecting citizens' digital data rights.",
         "publishedAt":"2025-03-05T10:00:00Z"},
        {"title":"Election Commission launches voter awareness drive for Gen Z",
         "source":"Times of India","summary":"ECI targets first-time voters aged 18-25 with social media campaigns.",
         "publishedAt":"2025-03-04T08:00:00Z"},
        {"title":"Supreme Court reaffirms Right to Privacy as Fundamental Right",
         "source":"Indian Express","summary":"Apex court upholds privacy under Article 21 in landmark judgment.",
         "publishedAt":"2025-03-03T16:00:00Z"},
    ]

QUIZ_BANK = {
    "parliament": [
        {"question":"How many elected seats does the Lok Sabha have?",
         "option_a":"543","option_b":"250","option_c":"790","option_d":"400","correct":"A",
         "explanation":"Lok Sabha has 543 elected seats representing constituencies across India."},
        {"question":"Which house of Parliament is called the Upper House?",
         "option_a":"Lok Sabha","option_b":"Rajya Sabha","option_c":"Vidhan Sabha","option_d":"Cabinet",
         "correct":"B","explanation":"Rajya Sabha, the Council of States, is the Upper House of Parliament."},
    ],
    "constitution": [
        {"question":"When did the Indian Constitution come into effect?",
         "option_a":"Aug 15 1947","option_b":"Jan 26 1950","option_c":"Nov 26 1949","option_d":"Jan 26 1952",
         "correct":"B","explanation":"The Constitution came into effect on January 26, 1950 — Republic Day."},
        {"question":"Who is the 'Father of the Indian Constitution'?",
         "option_a":"Jawaharlal Nehru","option_b":"Mahatma Gandhi","option_c":"Dr. B.R. Ambedkar","option_d":"Sardar Patel",
         "correct":"C","explanation":"Dr. B.R. Ambedkar chaired the Drafting Committee."},
    ],
    "elections": [
        {"question":"What is the minimum voting age in India?",
         "option_a":"16","option_b":"21","option_c":"18","option_d":"25",
         "correct":"C","explanation":"The 61st Constitutional Amendment lowered the voting age to 18 years."},
        {"question":"Which body conducts elections in India?",
         "option_a":"Supreme Court","option_b":"Election Commission of India","option_c":"UPSC","option_d":"Cabinet",
         "correct":"B","explanation":"ECI is the autonomous constitutional authority administering Indian elections."},
    ],
    "general": [
        {"question":"What does RTI stand for?",
         "option_a":"Right to Information","option_b":"Right to Independence","option_c":"Right to Internet","option_d":"Rules and Titles Index",
         "correct":"A","explanation":"RTI Act 2005 empowers citizens to request information from the government."},
        {"question":"When was GST introduced in India?",
         "option_a":"April 1 2016","option_b":"July 1 2017","option_c":"Jan 1 2018","option_d":"March 31 2016",
         "correct":"B","explanation":"GST launched July 1, 2017, replacing multiple indirect taxes."},
        {"question":"How many Fundamental Rights does the Indian Constitution guarantee?",
         "option_a":"5","option_b":"7","option_c":"6","option_d":"9",
         "correct":"C","explanation":"The Constitution guarantees 6 Fundamental Rights under Part III."},
    ]
}

@app.post("/api/quiz/generate")
def generate_quiz(req: QuizGenRequest):
    bank = next((v for k, v in QUIZ_BANK.items() if k in req.topic.lower()), QUIZ_BANK["general"])
    questions = bank[:req.num_questions]
    return {"title": f"Quiz: {req.topic.title()}", "category": req.topic,
            "questions": questions, "total": len(questions), "difficulty": req.difficulty}

@app.post("/api/policy/simulate")
def simulate_policy(req: PolicySimRequest):
    impact = req.impact_json
    analysis = []
    for domain, score in impact.items():
        if score > 3:      analysis.append(f"✅ Strong positive on {domain.title()}: +{score}/5")
        elif score > 0:    analysis.append(f"📈 Moderate positive on {domain.title()}: +{score}/5")
        elif score == 0:   analysis.append(f"⚖️ Neutral on {domain.title()}")
        elif score > -3:   analysis.append(f"📉 Moderate negative on {domain.title()}: {score}/5")
        else:              analysis.append(f"❌ Strong negative on {domain.title()}: {score}/5")
    total = sum(impact.values())
    verdict = ("Highly Recommended" if total > 5 else "Recommended" if total > 0
               else "Neutral" if total == 0 else "Caution Advised" if total > -5 else "Not Recommended")
    return {"option": req.option_label, "impact": impact, "analysis": analysis,
            "total_score": total, "verdict": verdict}

@app.post("/api/bills/explain")
def explain_bill(req: BillRequest):
    summary = extractive_summary(req.raw_text, 3)
    sentences = nltk.sent_tokenize(req.raw_text)
    key_points = [s.strip() for s in sentences
                  if any(kw in s.lower() for kw in ["shall","must","require","prohibit","mandate","establish"])][:5]
    if req.language != "en":
        t = translate_via_sarvam(summary, req.language)
        if t: summary = t
    return {"title": req.title, "simple_summary": summary, "key_points": key_points, "language": req.language}

@app.post("/api/translate")
def translate(req: TranslateRequest):
    result = translate_via_sarvam(req.text, req.target_language)
    return {"original": req.text, "translated": result or req.text,
            "language": req.target_language, "provider": "sarvam-ai" if result else "passthrough"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=5000, reload=True)
