import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import HomePage from './pages/HomePage';
import TutorPage from './pages/TutorPage';
import NewsPage from './pages/NewsPage';
import QuizPage from './pages/QuizPage';
import PollPage from './pages/PollPage';
import PolicySimPage from './pages/PolicySimPage';
import '@fontsource/bebas-neue'; // fallback handled via Google Fonts

const NAV_LINKS = [
  { to:'/', label:'Home' }, { to:'/tutor', label:'AI Tutor' },
  { to:'/news', label:'News' }, { to:'/quiz', label:'Quiz' },
  { to:'/polls', label:'Polls' }, { to:'/simulation', label:'Simulation' },
];

function Navbar() {
  const { user, logout, isLoggedIn } = useAuth();
  const loc = useLocation();
  return (
    <nav style={ns.nav}>
      <Link to="/" style={ns.logo}>CivicIQ</Link>
      <div style={ns.links}>
        {NAV_LINKS.map(l => (
          <Link key={l.to} to={l.to}
            style={{ ...ns.link, ...(loc.pathname===l.to ? ns.active : {}) }}>{l.label}</Link>
        ))}
      </div>
      <div style={ns.right}>
        {isLoggedIn ? (
          <>
            <span style={ns.user}>👤 {user?.name}</span>
            <button onClick={logout} style={ns.logoutBtn}>Logout</button>
          </>
        ) : (
          <Link to="/login" style={ns.loginBtn}>Login / Register</Link>
        )}
      </div>
    </nav>
  );
}

function LoginPage() {
  const { login, register } = useAuth();
  const nav = () => { window.history.back(); };
  const [mode, setMode] = React.useState('login');
  const [form, setForm] = React.useState({ name:'', email:'', password:'', language:'en' });
  const [err, setErr] = React.useState('');

  const submit = async () => {
    setErr('');
    try {
      if (mode === 'login') await login(form.email, form.password);
      else await register(form);
      nav();
    } catch (e) { setErr(e.response?.data?.error || 'Something went wrong'); }
  };

  return (
    <div style={ls.page}>
      <div style={ls.card}>
        <div style={ls.logo}>CivicIQ</div>
        <div style={ls.tabs}>
          <button onClick={() => setMode('login')} style={{ ...ls.tab, ...(mode==='login'?ls.tabActive:{}) }}>Login</button>
          <button onClick={() => setMode('register')} style={{ ...ls.tab, ...(mode==='register'?ls.tabActive:{}) }}>Register</button>
        </div>
        {mode==='register' && <input placeholder="Your Name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} style={ls.input}/>}
        <input placeholder="Email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} style={ls.input}/>
        <input placeholder="Password" type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} style={ls.input}/>
        {err && <p style={ls.err}>{err}</p>}
        <button onClick={submit} style={ls.submitBtn}>{mode==='login'?'Login':'Create Account'}</button>
      </div>
    </div>
  );
}

import React from 'react';
function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <div style={{ minHeight:'100vh', background:'#050a0e', color:'#e8f4f8' }}>
          <Navbar />
          <div style={{ paddingTop:70 }}>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/tutor" element={<TutorPage />} />
              <Route path="/news" element={<NewsPage />} />
              <Route path="/quiz" element={<QuizPage />} />
              <Route path="/polls" element={<PollPage />} />
              <Route path="/simulation" element={<PolicySimPage />} />
              <Route path="/login" element={<LoginPage />} />
            </Routes>
          </div>
          <footer style={fs.footer}>
            <span style={fs.logo}>CivicIQ</span>
            <span style={fs.text}>© 2025 Team IQ · V.S.B Engineering College, Karur</span>
            <span style={fs.text}>Built with ❤️ for Gen Z India</span>
          </footer>
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;

const ns = {
  nav:{ position:'fixed', top:0, width:'100%', zIndex:100, display:'flex', alignItems:'center',
    justifyContent:'space-between', padding:'.9rem 2rem', background:'rgba(5,10,14,.9)',
    backdropFilter:'blur(20px)', borderBottom:'1px solid rgba(0,245,212,.1)', gap:'1rem', flexWrap:'wrap' },
  logo:{ fontFamily:'"Bebas Neue",cursive', fontSize:'1.6rem', letterSpacing:3, textDecoration:'none',
    background:'linear-gradient(90deg,#00f5d4,#a78bfa)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' },
  links:{ display:'flex', gap:'1.5rem', flexWrap:'wrap' },
  link:{ color:'#7a98b0', textDecoration:'none', fontSize:'.9rem', fontFamily:'DM Sans,sans-serif', transition:'color .2s' },
  active:{ color:'#00f5d4', fontWeight:600 },
  right:{ display:'flex', gap:'1rem', alignItems:'center' },
  user:{ color:'#7a98b0', fontSize:'.85rem', fontFamily:'DM Sans,sans-serif' },
  loginBtn:{ background:'#00f5d4', color:'#050a0e', borderRadius:20, padding:'.4rem 1.2rem',
    textDecoration:'none', fontSize:'.85rem', fontWeight:700, fontFamily:'DM Sans,sans-serif' },
  logoutBtn:{ background:'transparent', border:'1px solid rgba(255,107,107,.4)', color:'#ff6b6b',
    borderRadius:20, padding:'.4rem 1rem', fontSize:'.8rem', cursor:'pointer', fontFamily:'DM Sans,sans-serif' },
};
const ls = {
  page:{ minHeight:'80vh', display:'flex', alignItems:'center', justifyContent:'center', padding:'2rem' },
  card:{ background:'#0d1821', border:'1px solid rgba(0,245,212,.15)', borderRadius:20, padding:'3rem', width:'100%', maxWidth:420 },
  logo:{ fontFamily:'"Bebas Neue",cursive', fontSize:'2rem', letterSpacing:3,
    background:'linear-gradient(90deg,#00f5d4,#a78bfa)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent',
    textAlign:'center', marginBottom:'2rem', display:'block' },
  tabs:{ display:'flex', gap:'.5rem', marginBottom:'1.5rem' },
  tab:{ flex:1, background:'rgba(255,255,255,.04)', border:'1px solid rgba(255,255,255,.1)', color:'#7a98b0',
    borderRadius:8, padding:'.6rem', cursor:'pointer', fontFamily:'DM Sans,sans-serif' },
  tabActive:{ background:'rgba(0,245,212,.1)', borderColor:'#00f5d4', color:'#00f5d4', fontWeight:700 },
  input:{ display:'block', width:'100%', background:'rgba(255,255,255,.04)', border:'1px solid rgba(255,255,255,.1)',
    color:'#e8f4f8', borderRadius:8, padding:'.85rem 1rem', fontSize:'1rem', marginBottom:'1rem', fontFamily:'DM Sans,sans-serif', boxSizing:'border-box' },
  err:{ color:'#ff6b6b', fontSize:'.85rem', marginBottom:'1rem' },
  submitBtn:{ width:'100%', background:'#00f5d4', color:'#050a0e', border:'none', borderRadius:8,
    padding:'.85rem', fontSize:'1rem', fontWeight:700, cursor:'pointer', fontFamily:'DM Sans,sans-serif' },
};
const fs = {
  footer:{ background:'#0d1821', borderTop:'1px solid rgba(0,245,212,.1)', padding:'2rem',
    display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:'1rem',
    fontFamily:'DM Sans,sans-serif' },
  logo:{ fontFamily:'"Bebas Neue",cursive', fontSize:'1.3rem', letterSpacing:3,
    background:'linear-gradient(90deg,#00f5d4,#a78bfa)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' },
  text:{ color:'#7a98b0', fontSize:'.85rem' },
};
