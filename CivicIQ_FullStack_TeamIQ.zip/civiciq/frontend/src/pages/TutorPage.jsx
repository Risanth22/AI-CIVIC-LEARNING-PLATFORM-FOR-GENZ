import { useState, useRef, useEffect } from 'react';
import { askTutor } from '../services/api';

const LANGUAGES = [
  { code:'en', label:'English' }, { code:'hi', label:'हिंदी' },
  { code:'ta', label:'தமிழ்' }, { code:'te', label:'తెలుగు' },
  { code:'kn', label:'ಕನ್ನಡ' }, { code:'ml', label:'മലയാളം' },
  { code:'bn', label:'বাংলা' }, { code:'gu', label:'ગુજરાતી' },
];

const QUICK = [
  'What is the Indian Parliament?', 'How do elections work in India?',
  'What are Fundamental Rights?', 'What is GST?',
  'How does the Supreme Court work?', 'What is RTI?',
];

export default function TutorPage() {
  const [messages, setMessages] = useState([
    { role:'assistant', content:'Namaste! 🙏 I am your AI Civic Tutor. Ask me anything about Indian politics, Parliament, Constitution, elections, or governance — in any Indian language!' }
  ]);
  const [input, setInput] = useState('');
  const [language, setLanguage] = useState('en');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior:'smooth' }); }, [messages]);

  const send = async (question) => {
    const q = question || input.trim();
    if (!q) return;
    setMessages(m => [...m, { role:'user', content: q }]);
    setInput('');
    setLoading(true);
    try {
      const res = await askTutor(q, language);
      setMessages(m => [...m, { role:'assistant', content: res.data.answer,
        sources: res.data.sources }]);
    } catch {
      setMessages(m => [...m, { role:'assistant', content:'Sorry, I could not connect to the AI service. Please try again.' }]);
    } finally { setLoading(false); }
  };

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <h1 style={styles.title}>🤖 AI Civic Tutor</h1>
        <p style={styles.sub}>Ask anything about Indian governance, politics & civics</p>
        <select value={language} onChange={e => setLanguage(e.target.value)} style={styles.langSelect}>
          {LANGUAGES.map(l => <option key={l.code} value={l.code}>{l.label}</option>)}
        </select>
      </div>

      <div style={styles.quickRow}>
        {QUICK.map(q => (
          <button key={q} onClick={() => send(q)} style={styles.quickBtn}>{q}</button>
        ))}
      </div>

      <div style={styles.chatBox}>
        {messages.map((m, i) => (
          <div key={i} style={m.role==='user' ? styles.userMsg : styles.botMsg}>
            <div style={styles.msgBubble(m.role)}>
              <span style={styles.roleIcon}>{m.role==='user' ? '👤' : '🤖'}</span>
              <div>
                <p style={styles.msgText}>{m.content}</p>
                {m.sources && <p style={styles.sources}>📚 {m.sources.join(' · ')}</p>}
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div style={styles.botMsg}>
            <div style={styles.msgBubble('assistant')}>
              <span>🤖</span>
              <div style={styles.typing}><span/><span/><span/></div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div style={styles.inputRow}>
        <input value={input} onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key==='Enter' && send()}
          placeholder="Ask about Parliament, Elections, Constitution..."
          style={styles.input} />
        <button onClick={() => send()} style={styles.sendBtn} disabled={loading}>Send ➤</button>
      </div>
    </div>
  );
}

const styles = {
  page: { maxWidth:900, margin:'0 auto', padding:'2rem 1rem', fontFamily:'DM Sans,sans-serif' },
  header: { textAlign:'center', marginBottom:'1.5rem' },
  title: { fontSize:'2rem', color:'#00f5d4', marginBottom:'.3rem' },
  sub: { color:'#7a98b0', marginBottom:'1rem' },
  langSelect: { background:'#0d1821', color:'#e8f4f8', border:'1px solid rgba(0,245,212,.3)',
    borderRadius:8, padding:'.4rem 1rem', fontSize:'.9rem' },
  quickRow: { display:'flex', flexWrap:'wrap', gap:'.5rem', marginBottom:'1.5rem', justifyContent:'center' },
  quickBtn: { background:'rgba(0,245,212,.08)', border:'1px solid rgba(0,245,212,.2)', color:'#00f5d4',
    borderRadius:20, padding:'.4rem 1rem', fontSize:'.8rem', cursor:'pointer' },
  chatBox: { background:'#0d1821', borderRadius:16, padding:'1.5rem', minHeight:400,
    maxHeight:500, overflowY:'auto', border:'1px solid rgba(0,245,212,.1)', marginBottom:'1rem' },
  userMsg: { display:'flex', justifyContent:'flex-end', marginBottom:'1rem' },
  botMsg: { display:'flex', justifyContent:'flex-start', marginBottom:'1rem' },
  msgBubble: (role) => ({
    display:'flex', gap:'0.75rem', alignItems:'flex-start', maxWidth:'80%',
    background: role==='user' ? 'rgba(0,245,212,.12)' : 'rgba(167,139,250,.1)',
    border: `1px solid ${role==='user' ? 'rgba(0,245,212,.3)' : 'rgba(167,139,250,.3)'}`,
    borderRadius:12, padding:'1rem'
  }),
  roleIcon: { fontSize:'1.2rem', minWidth:24 },
  msgText: { color:'#e8f4f8', lineHeight:1.6, margin:0 },
  sources: { color:'#7a98b0', fontSize:'.75rem', marginTop:'.4rem', marginBottom:0 },
  typing: { display:'flex', gap:4, alignItems:'center', height:24 },
  inputRow: { display:'flex', gap:'.75rem' },
  input: { flex:1, background:'#0d1821', border:'1px solid rgba(0,245,212,.3)', color:'#e8f4f8',
    borderRadius:10, padding:'.85rem 1.2rem', fontSize:'1rem', outline:'none' },
  sendBtn: { background:'#00f5d4', color:'#050a0e', border:'none', borderRadius:10,
    padding:'.85rem 2rem', fontSize:'1rem', fontWeight:700, cursor:'pointer' },
};
