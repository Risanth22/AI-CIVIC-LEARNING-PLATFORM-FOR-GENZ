import { useNavigate } from 'react-router-dom';

const FEATURES = [
  { icon:'🤖', title:'AI Civic Tutor', desc:'Ask anything about Indian governance in 22+ Indian languages. Powered by NLP + Sarvam AI.', color:'#00f5d4', path:'/tutor' },
  { icon:'📰', title:'Simplified News', desc:'Real-time political news from verified sources, summarized by AI. Zero misinformation.', color:'#a78bfa', path:'/news' },
  { icon:'⚡', title:'Real-Time Quiz Bot', desc:'AI-generated quizzes from current political events, bills, and constitutional topics.', color:'#ffd166', path:'/quiz' },
  { icon:'🗳️', title:'Civic Poll System', desc:'Vote on real policy questions and compare your opinion with other Gen Z citizens.', color:'#ff6b6b', path:'/polls' },
  { icon:'🏛️', title:'Policy Simulation', desc:'Make real policy decisions and instantly see their impact on society, economy and environment.', color:'#a78bfa', path:'/simulation' },
  { icon:'📜', title:'"Bill Passed" Module', desc:'Every new law explained in simple language the moment it passes Parliament.', color:'#00f5d4', path:'/bills' },
];

const STATS = [
  { n:'7', label:'AI Features' }, { n:'22+', label:'Indian Languages' },
  { n:'5', label:'Tech Layers' }, { n:'100%', label:'Verified News' },
];

export default function HomePage() {
  const nav = useNavigate();
  return (
    <div style={s.page}>
      {/* HERO */}
      <div style={s.hero}>
        <div style={s.badge}>🟢 AI-Powered Civic Learning Platform</div>
        <h1 style={s.heroTitle}>Politics for<br/><span style={s.gradient}>Gen Z</span></h1>
        <p style={s.heroSub}>
          An AI-driven platform that makes civic education accessible, engaging,
          and misinformation-free — built for digital-native Indian learners.
        </p>
        <div style={s.heroBtns}>
          <button onClick={() => nav('/tutor')} style={s.primaryBtn}>🚀 Start Learning</button>
          <button onClick={() => nav('/quiz')} style={s.secondaryBtn}>Take a Quiz ⚡</button>
        </div>
        <div style={s.statsRow}>
          {STATS.map(st => (
            <div key={st.label} style={s.stat}>
              <div style={s.statNum}>{st.n}</div>
              <div style={s.statLabel}>{st.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* FEATURES */}
      <h2 style={s.sectionTitle}>What CivicIQ Offers</h2>
      <div style={s.featureGrid}>
        {FEATURES.map(f => (
          <div key={f.title} style={s.featureCard} onClick={() => nav(f.path)}>
            <div style={{ ...s.featureIcon, background:`${f.color}18`, color:f.color }}>{f.icon}</div>
            <h3 style={{ ...s.featureTitle, color:f.color }}>{f.title}</h3>
            <p style={s.featureDesc}>{f.desc}</p>
            <span style={{ ...s.featureLink, color:f.color }}>Explore →</span>
          </div>
        ))}
      </div>

      {/* SARVAM AI HIGHLIGHT */}
      <div style={s.highlight}>
        <div style={s.highlightIcon}>🇮🇳</div>
        <div>
          <h3 style={s.highlightTitle}>Sarvam AI — 22+ Indian Languages</h3>
          <p style={s.highlightDesc}>
            CivicIQ integrates Sarvam AI, an Indian-developed multilingual model, to deliver
            civic education in Hindi, Tamil, Telugu, Kannada, Malayalam, Bengali, Gujarati,
            Punjabi, and more — making civic learning truly inclusive.
          </p>
        </div>
      </div>

      {/* TECH STACK */}
      <h2 style={s.sectionTitle}>Technology Stack</h2>
      <div style={s.techGrid}>
        {[
          { cat:'Frontend', items:['React.js','HTML5','CSS3','Chart.js'], color:'#61dafb' },
          { cat:'Backend', items:['Java Spring Boot','REST APIs','JWT Auth'], color:'#6db33f' },
          { cat:'AI / NLP', items:['FastAPI (Python)','NLTK','Sarvam AI','NewsAPI'], color:'#00f5d4' },
          { cat:'Database', items:['MySQL 8','JPA/Hibernate','Data Visualization'], color:'#4479a1' },
          { cat:'Deployment', items:['Docker','Docker Compose','Nginx'], color:'#2496ed' },
        ].map(tech => (
          <div key={tech.cat} style={s.techCard}>
            <div style={{ ...s.techCat, color:tech.color }}>{tech.cat}</div>
            {tech.items.map(item => (
              <span key={item} style={{ ...s.techTag, borderColor:`${tech.color}40`, color:tech.color }}>{item}</span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

const s = {
  page:{ fontFamily:'DM Sans,sans-serif', maxWidth:1100, margin:'0 auto', padding:'2rem 1rem' },
  hero:{ textAlign:'center', padding:'4rem 1rem 3rem', borderBottom:'1px solid rgba(0,245,212,.1)' },
  badge:{ display:'inline-block', background:'rgba(0,245,212,.08)', border:'1px solid rgba(0,245,212,.2)',
    color:'#00f5d4', borderRadius:20, padding:'.35rem 1rem', fontSize:'.8rem', marginBottom:'1.5rem', letterSpacing:'.05em' },
  heroTitle:{ fontFamily:'"Bebas Neue",cursive', fontSize:'clamp(3rem,10vw,7rem)', lineHeight:.9,
    color:'#e8f4f8', margin:'0 0 1rem', letterSpacing:2 },
  gradient:{ background:'linear-gradient(90deg,#00f5d4,#a78bfa)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' },
  heroSub:{ color:'#7a98b0', fontSize:'1.1rem', maxWidth:560, margin:'0 auto 2rem', lineHeight:1.7 },
  heroBtns:{ display:'flex', gap:'1rem', justifyContent:'center', flexWrap:'wrap', marginBottom:'3rem' },
  primaryBtn:{ background:'#00f5d4', color:'#050a0e', border:'none', borderRadius:100,
    padding:'.85rem 2.5rem', fontSize:'1rem', fontWeight:700, cursor:'pointer' },
  secondaryBtn:{ background:'transparent', color:'#e8f4f8', border:'1.5px solid rgba(0,245,212,.3)',
    borderRadius:100, padding:'.85rem 2.5rem', fontSize:'1rem', fontWeight:600, cursor:'pointer' },
  statsRow:{ display:'flex', justifyContent:'center', gap:'3rem', flexWrap:'wrap' },
  stat:{ textAlign:'center' },
  statNum:{ fontFamily:'"Bebas Neue",cursive', fontSize:'3rem', color:'#00f5d4', lineHeight:1 },
  statLabel:{ color:'#7a98b0', fontSize:'.8rem', marginTop:'.25rem' },
  sectionTitle:{ fontFamily:'"Bebas Neue",cursive', fontSize:'2.5rem', color:'#e8f4f8',
    margin:'4rem 0 2rem', letterSpacing:2 },
  featureGrid:{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))', gap:'1.5rem', marginBottom:'3rem' },
  featureCard:{ background:'#0d1821', border:'1px solid rgba(255,255,255,.08)', borderRadius:16,
    padding:'2rem', cursor:'pointer', transition:'all .2s', display:'flex', flexDirection:'column', gap:'.75rem' },
  featureIcon:{ width:52, height:52, borderRadius:14, display:'flex', alignItems:'center',
    justifyContent:'center', fontSize:'1.5rem' },
  featureTitle:{ fontSize:'1.1rem', fontWeight:700, margin:0 },
  featureDesc:{ color:'#7a98b0', fontSize:'.9rem', lineHeight:1.6, flex:1 },
  featureLink:{ fontSize:'.85rem', fontWeight:600 },
  highlight:{ background:'linear-gradient(135deg,rgba(0,245,212,.05),rgba(167,139,250,.05))',
    border:'1px solid rgba(167,139,250,.3)', borderRadius:20, padding:'2.5rem',
    display:'flex', gap:'2rem', alignItems:'center', marginBottom:'3rem', flexWrap:'wrap' },
  highlightIcon:{ fontSize:'3.5rem', minWidth:64, textAlign:'center' },
  highlightTitle:{ color:'#a78bfa', fontSize:'1.2rem', fontWeight:700, marginBottom:'.5rem' },
  highlightDesc:{ color:'#7a98b0', lineHeight:1.6 },
  techGrid:{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(180px,1fr))', gap:'1rem', marginBottom:'4rem' },
  techCard:{ background:'#0d1821', border:'1px solid rgba(255,255,255,.08)', borderRadius:12, padding:'1.3rem' },
  techCat:{ fontSize:'.75rem', fontWeight:700, letterSpacing:'.1em', textTransform:'uppercase', marginBottom:'.75rem', paddingBottom:'.5rem', borderBottom:'1px solid rgba(255,255,255,.06)' },
  techTag:{ display:'inline-block', border:'1px solid', borderRadius:6, padding:'.2rem .5rem',
    fontSize:'.78rem', margin:'0 .3rem .3rem 0' },
};
