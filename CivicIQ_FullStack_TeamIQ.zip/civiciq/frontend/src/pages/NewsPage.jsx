import { useState, useEffect } from 'react';
import { fetchLiveNews } from '../services/api';

export default function NewsPage() {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    fetchLiveNews().then(r => {
      setArticles(r.data.articles || []);
      setLoading(false);
    }).catch(() => { setArticles(DEMO); setLoading(false); });
  }, []);

  return (
    <div style={s.page}>
      <h1 style={s.title}>📰 Simplified Political News</h1>
      <p style={s.sub}>Real-time news from verified sources — summarized by AI, zero misinformation.</p>
      {loading ? <p style={s.loading}>Fetching latest news...</p> : (
        <div style={s.grid}>
          {articles.map((a, i) => (
            <div key={i} style={s.card} onClick={() => setExpanded(expanded===i ? null : i)}>
              <div style={s.cardTop}>
                <span style={s.source}>{a.source || 'Verified Source'}</span>
                <span style={s.verified}>✅ Verified</span>
              </div>
              <h3 style={s.cardTitle}>{a.title}</h3>
              <p style={s.summary}>{a.summary}</p>
              {expanded===i && a.url && (
                <a href={a.url} target="_blank" rel="noopener noreferrer" style={s.readMore}>
                  Read Full Article →
                </a>
              )}
              <div style={s.cardBottom}>
                <span style={s.date}>{a.publishedAt ? new Date(a.publishedAt).toLocaleDateString() : 'Today'}</span>
                <span style={s.expand}>{expanded===i ? 'Show less ▲' : 'Read more ▼'}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const DEMO = [
  { title:'Parliament passes Digital Personal Data Protection Bill', source:'The Hindu',
    summary:'Parliament passed the DPDP Bill protecting citizens digital data rights with strict penalties for violations.',
    publishedAt:'2025-03-05T10:00:00Z' },
  { title:'Election Commission launches Gen Z voter awareness drive', source:'Times of India',
    summary:'ECI targets first-time voters aged 18-25 with social media campaigns and simplified voter registration.',
    publishedAt:'2025-03-04T08:00:00Z' },
  { title:'Supreme Court upholds Right to Privacy under Article 21', source:'Indian Express',
    summary:'Apex court reaffirms privacy as a fundamental right in landmark judgment affecting data collection policies.',
    publishedAt:'2025-03-03T16:00:00Z' },
];

const s = {
  page: { maxWidth:1000, margin:'0 auto', padding:'2rem 1rem', fontFamily:'DM Sans,sans-serif' },
  title: { fontSize:'2rem', color:'#00f5d4', marginBottom:'.3rem' },
  sub: { color:'#7a98b0', marginBottom:'2rem' },
  loading: { color:'#7a98b0', textAlign:'center', padding:'2rem' },
  grid: { display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))', gap:'1.5rem' },
  card: { background:'#0d1821', border:'1px solid rgba(0,245,212,.12)', borderRadius:16,
    padding:'1.5rem', cursor:'pointer', transition:'all .2s',
    ':hover': { borderColor:'rgba(0,245,212,.4)' } },
  cardTop: { display:'flex', justifyContent:'space-between', marginBottom:'.75rem' },
  source: { color:'#a78bfa', fontSize:'.8rem', fontWeight:600 },
  verified: { color:'#00f5d4', fontSize:'.75rem' },
  cardTitle: { color:'#e8f4f8', fontSize:'1rem', marginBottom:'.75rem', lineHeight:1.4 },
  summary: { color:'#7a98b0', fontSize:'.9rem', lineHeight:1.6, marginBottom:'.75rem' },
  readMore: { display:'block', color:'#00f5d4', fontSize:'.85rem', marginBottom:'.75rem', textDecoration:'none' },
  cardBottom: { display:'flex', justifyContent:'space-between', borderTop:'1px solid rgba(255,255,255,.06)', paddingTop:'.75rem' },
  date: { color:'#7a98b0', fontSize:'.8rem' },
  expand: { color:'#00f5d4', fontSize:'.8rem' },
};
