import { useState } from 'react';
import { simulatePolicy } from '../services/api';

const SCENARIOS = [
  { id:1, title:'National Education Budget', description:'Which approach to the education budget do you choose?', domain:'EDUCATION',
    options:[
      { id:1, label:'Increase budget by 50%', impact:{economy:-2,education:5,health:1,environment:0,social:3} },
      { id:2, label:'Maintain current budget', impact:{economy:0,education:0,health:0,environment:0,social:0} },
      { id:3, label:'Redirect funds to tech education', impact:{economy:3,education:3,health:0,environment:0,social:1} },
    ]},
  { id:2, title:'Climate Action Plan', description:'India needs a new climate policy commitment. Which do you prefer?', domain:'ENVIRONMENT',
    options:[
      { id:4, label:'Carbon neutral by 2040', impact:{economy:-1,education:0,health:3,environment:5,social:2} },
      { id:5, label:'Gradual transition by 2060', impact:{economy:1,education:0,health:1,environment:2,social:1} },
      { id:6, label:'Prioritize economic growth first', impact:{economy:4,education:0,health:-1,environment:-3,social:0} },
    ]},
];

const DOMAIN_ICON = { economy:'💰', education:'📚', health:'🏥', environment:'🌱', social:'👥' };

export default function PolicySimPage() {
  const [scenIdx, setScenIdx] = useState(0);
  const [selected, setSelected] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const scenario = SCENARIOS[scenIdx];

  const simulate = async () => {
    if (!selected) return;
    setLoading(true);
    const opt = scenario.options.find(o => o.id === selected);
    try {
      const r = await simulatePolicy({ option_label: opt.label, impact_json: opt.impact });
      setResult(r.data);
    } catch {
      setResult({ option: opt.label, impact: opt.impact, verdict:'Analysis complete', total_score: Object.values(opt.impact).reduce((a,b)=>a+b,0),
        analysis: Object.entries(opt.impact).map(([k,v]) => `${v>0?'📈':'v<0?📉':'⚖️'} ${k}: ${v>0?'+':''}${v}/5`) });
    } finally { setLoading(false); }
  };

  return (
    <div style={s.page}>
      <h1 style={s.title}>🏛️ Policy Simulation</h1>
      <p style={s.sub}>Make a policy decision and see its impact on society, economy & environment</p>

      <div style={s.tabs}>
        {SCENARIOS.map((sc, i) => (
          <button key={sc.id} onClick={() => { setScenIdx(i); setSelected(null); setResult(null); }}
            style={{ ...s.tab, ...(i===scenIdx ? s.tabActive : {}) }}>
            {sc.title}
          </button>
        ))}
      </div>

      <div style={s.scenCard}>
        <span style={s.domain}>{scenario.domain}</span>
        <h2 style={s.scenTitle}>{scenario.title}</h2>
        <p style={s.scenDesc}>{scenario.description}</p>

        <div style={s.optionsGrid}>
          {scenario.options.map(opt => (
            <button key={opt.id} onClick={() => { setSelected(opt.id); setResult(null); }}
              style={{ ...s.optBtn, ...(selected===opt.id ? s.optSelected : {}) }}>
              <strong style={s.optLabel}>{opt.label}</strong>
              <div style={s.impactRow}>
                {Object.entries(opt.impact).map(([k,v]) => (
                  <span key={k} style={{ ...s.impactBadge, color: v>0?'#00f5d4':v<0?'#ff6b6b':'#7a98b0' }}>
                    {DOMAIN_ICON[k]} {v>0?'+':''}{v}
                  </span>
                ))}
              </div>
            </button>
          ))}
        </div>

        <button onClick={simulate} style={s.simBtn} disabled={!selected||loading}>
          {loading ? 'Simulating...' : '▶ Run Simulation'}
        </button>
      </div>

      {result && (
        <div style={s.resultCard}>
          <h3 style={s.resultTitle}>📊 Simulation Results: {result.option}</h3>
          <div style={s.metersGrid}>
            {Object.entries(result.impact).map(([domain, score]) => (
              <div key={domain} style={s.meter}>
                <div style={s.meterHeader}>
                  <span>{DOMAIN_ICON[domain]} {domain.charAt(0).toUpperCase()+domain.slice(1)}</span>
                  <span style={{ color: score>0?'#00f5d4':score<0?'#ff6b6b':'#7a98b0' }}>
                    {score>0?'+':''}{score}/5
                  </span>
                </div>
                <div style={s.meterBar}>
                  <div style={{ ...s.meterFill, width:`${Math.abs(score)/5*100}%`,
                    background: score>0?'#00f5d4':score<0?'#ff6b6b':'#7a98b0',
                    marginLeft: score<0 ? `${50+score/5*50}%` : '50%' }} />
                </div>
              </div>
            ))}
          </div>
          <div style={{ ...s.verdict, background: result.total_score>0?'rgba(0,245,212,.1)':'rgba(255,107,107,.1)',
            borderColor: result.total_score>0?'#00f5d4':'#ff6b6b' }}>
            <strong style={{ color: result.total_score>0?'#00f5d4':'#ff6b6b' }}>
              Verdict: {result.verdict}
            </strong>
            <span style={{ color:'#7a98b0', marginLeft:'1rem' }}>
              Net welfare score: {result.total_score>0?'+':''}{result.total_score}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

const s = {
  page:{ maxWidth:1000, margin:'0 auto', padding:'2rem 1rem', fontFamily:'DM Sans,sans-serif' },
  title:{ fontSize:'2rem', color:'#a78bfa', marginBottom:'.3rem' },
  sub:{ color:'#7a98b0', marginBottom:'2rem' },
  tabs:{ display:'flex', gap:'.75rem', marginBottom:'1.5rem', flexWrap:'wrap' },
  tab:{ background:'rgba(167,139,250,.08)', border:'1px solid rgba(167,139,250,.2)', color:'#7a98b0',
    borderRadius:10, padding:'.6rem 1.5rem', cursor:'pointer', fontSize:'.9rem' },
  tabActive:{ background:'rgba(167,139,250,.2)', borderColor:'#a78bfa', color:'#a78bfa', fontWeight:700 },
  scenCard:{ background:'#0d1821', border:'1px solid rgba(167,139,250,.15)', borderRadius:16, padding:'2rem', marginBottom:'2rem' },
  domain:{ background:'rgba(167,139,250,.12)', color:'#a78bfa', borderRadius:20,
    padding:'.2rem .8rem', fontSize:'.75rem', fontWeight:700 },
  scenTitle:{ color:'#e8f4f8', margin:'1rem 0 .5rem', fontSize:'1.4rem' },
  scenDesc:{ color:'#7a98b0', marginBottom:'1.5rem' },
  optionsGrid:{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(250px,1fr))', gap:'1rem', marginBottom:'1.5rem' },
  optBtn:{ background:'rgba(255,255,255,.03)', border:'1px solid rgba(255,255,255,.1)',
    borderRadius:12, padding:'1.2rem', cursor:'pointer', textAlign:'left', transition:'all .2s' },
  optSelected:{ borderColor:'#a78bfa', background:'rgba(167,139,250,.1)' },
  optLabel:{ color:'#e8f4f8', display:'block', marginBottom:'.75rem', fontSize:'.95rem' },
  impactRow:{ display:'flex', flexWrap:'wrap', gap:'.3rem' },
  impactBadge:{ fontSize:'.75rem', background:'rgba(255,255,255,.04)', borderRadius:6, padding:'.1rem .4rem' },
  simBtn:{ background:'#a78bfa', color:'#050a0e', border:'none', borderRadius:10,
    padding:'.85rem 2.5rem', fontSize:'1rem', fontWeight:700, cursor:'pointer' },
  resultCard:{ background:'#0d1821', border:'1px solid rgba(167,139,250,.2)', borderRadius:16, padding:'2rem' },
  resultTitle:{ color:'#a78bfa', marginBottom:'1.5rem' },
  metersGrid:{ display:'flex', flexDirection:'column', gap:'1rem', marginBottom:'1.5rem' },
  meter:{ background:'rgba(255,255,255,.03)', borderRadius:8, padding:'1rem' },
  meterHeader:{ display:'flex', justifyContent:'space-between', color:'#e8f4f8', marginBottom:'.5rem', fontSize:'.9rem' },
  meterBar:{ height:8, background:'rgba(255,255,255,.08)', borderRadius:4, position:'relative', overflow:'hidden' },
  meterFill:{ height:'100%', borderRadius:4, transition:'all .8s', position:'absolute' },
  verdict:{ border:'1px solid', borderRadius:10, padding:'1rem 1.5rem', display:'flex', alignItems:'center', flexWrap:'wrap', gap:'.5rem' },
};
