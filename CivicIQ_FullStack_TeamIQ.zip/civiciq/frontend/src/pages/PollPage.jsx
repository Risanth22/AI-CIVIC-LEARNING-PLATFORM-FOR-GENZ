import { useState, useEffect } from 'react';
import { getPolls, votePoll, getPollResults } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function PollPage() {
  const [polls, setPolls] = useState([]);
  const [results, setResults] = useState({});
  const [voted, setVoted] = useState({});
  const { isLoggedIn } = useAuth();

  useEffect(() => {
    getPolls().then(r => setPolls(r.data)).catch(() => setPolls(DEMO_POLLS));
  }, []);

  const loadResults = async (pollId) => {
    try {
      const r = await getPollResults(pollId);
      setResults(prev => ({ ...prev, [pollId]: r.data }));
    } catch {}
  };

  const handleVote = async (pollId, optionId) => {
    if (!isLoggedIn) return alert('Please login to vote!');
    try {
      await votePoll(pollId, optionId);
      setVoted(v => ({ ...v, [pollId]: optionId }));
      await loadResults(pollId);
    } catch (e) { alert(e.response?.data?.error || 'Vote failed'); }
  };

  return (
    <div style={s.page}>
      <h1 style={s.title}>🗳️ Civic Poll System</h1>
      <p style={s.sub}>Vote on real policy questions. Compare your opinion with thousands of Indians.</p>
      <div style={s.grid}>
        {polls.map(poll => {
          const res = results[poll.id];
          const total = res?.total || 0;
          return (
            <div key={poll.id} style={s.card}>
              <span style={s.category}>{poll.category || 'CIVIC'}</span>
              <h3 style={s.question}>{poll.question}</h3>
              <div style={s.options}>
                {(poll.options || []).map(opt => {
                  const votes = res?.voteCounts?.[opt.id] || 0;
                  const pct = total > 0 ? Math.round(votes/total*100) : 0;
                  const isVoted = voted[poll.id] === opt.id;
                  return (
                    <div key={opt.id} style={s.optWrap}>
                      <button onClick={() => handleVote(poll.id, opt.id)}
                        style={{ ...s.optBtn, ...(isVoted ? s.votedBtn : {}) }}>
                        {opt.label}
                        {isVoted && ' ✓'}
                      </button>
                      {res && (
                        <div style={s.barWrap}>
                          <div style={{ ...s.bar, width: `${pct}%` }} />
                          <span style={s.pct}>{pct}% ({votes})</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
              {!res && (
                <button onClick={() => loadResults(poll.id)} style={s.resultsBtn}>
                  View Results
                </button>
              )}
              {res && <p style={s.total}>Total votes: {total}</p>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

const DEMO_POLLS = [
  { id:1, question:'Should voting age be lowered to 16 in India?', category:'ELECTIONS',
    options:[{id:1,label:'Yes, 16-year-olds are mature enough'},{id:2,label:'No, keep it at 18'},{id:3,label:'Yes, with civic education first'}]},
  { id:2, question:'Which area needs most government focus in 2025?', category:'POLICY',
    options:[{id:4,label:'Education'},{id:5,label:'Healthcare'},{id:6,label:'Employment/Economy'},{id:7,label:'Climate & Environment'}]},
];

const s = {
  page:{ maxWidth:1000, margin:'0 auto', padding:'2rem 1rem', fontFamily:'DM Sans,sans-serif' },
  title:{ fontSize:'2rem', color:'#ff6b6b', marginBottom:'.3rem' },
  sub:{ color:'#7a98b0', marginBottom:'2rem' },
  grid:{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(400px,1fr))', gap:'1.5rem' },
  card:{ background:'#0d1821', border:'1px solid rgba(255,107,107,.15)', borderRadius:16, padding:'1.8rem' },
  category:{ background:'rgba(255,107,107,.12)', color:'#ff6b6b', borderRadius:20,
    padding:'.2rem .8rem', fontSize:'.75rem', fontWeight:700 },
  question:{ color:'#e8f4f8', margin:'1rem 0', fontSize:'1.1rem', lineHeight:1.5 },
  options:{ display:'flex', flexDirection:'column', gap:'.75rem' },
  optWrap:{ display:'flex', flexDirection:'column', gap:'.3rem' },
  optBtn:{ background:'rgba(255,255,255,.04)', border:'1px solid rgba(255,255,255,.12)',
    color:'#e8f4f8', borderRadius:8, padding:'.75rem 1rem', cursor:'pointer', textAlign:'left',
    fontSize:'.9rem', transition:'all .15s' },
  votedBtn:{ borderColor:'#ff6b6b', color:'#ff6b6b', background:'rgba(255,107,107,.1)' },
  barWrap:{ display:'flex', alignItems:'center', gap:'.75rem', height:6 },
  bar:{ height:'100%', background:'linear-gradient(90deg,#ff6b6b,#a78bfa)', borderRadius:3,
    transition:'width .5s', minWidth:4 },
  pct:{ color:'#7a98b0', fontSize:'.8rem', whiteSpace:'nowrap' },
  resultsBtn:{ background:'transparent', border:'1px solid rgba(255,107,107,.4)', color:'#ff6b6b',
    borderRadius:8, padding:'.6rem 1.5rem', cursor:'pointer', marginTop:'.75rem', fontSize:'.9rem' },
  total:{ color:'#7a98b0', fontSize:'.8rem', marginTop:'.75rem' },
};
