import { useState } from 'react';
import { generateQuiz } from '../services/api';

const TOPICS = ['Parliament','Constitution','Elections','General','GST','RTI','Judiciary'];

export default function QuizPage() {
  const [topic, setTopic] = useState('General');
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const startQuiz = async () => {
    setLoading(true); setSubmitted(false); setAnswers({});
    try {
      const r = await generateQuiz({ topic, num_questions: 5, difficulty: 'MEDIUM' });
      setQuiz(r.data);
    } catch { setQuiz(DEMO_QUIZ); }
    finally { setLoading(false); }
  };

  const score = quiz ? quiz.questions.filter((q, i) => answers[i] === q.correct).length : 0;

  return (
    <div style={s.page}>
      <h1 style={s.title}>⚡ Real-Time Quiz Bot</h1>
      <p style={s.sub}>Test your civic knowledge with AI-generated quizzes</p>

      <div style={s.topicRow}>
        {TOPICS.map(t => (
          <button key={t} onClick={() => setTopic(t)}
            style={{ ...s.topicBtn, ...(topic===t ? s.topicActive : {}) }}>{t}</button>
        ))}
      </div>

      <button onClick={startQuiz} style={s.startBtn} disabled={loading}>
        {loading ? 'Generating...' : `🎯 Start ${topic} Quiz`}
      </button>

      {quiz && (
        <div style={s.quizBox}>
          <h2 style={s.quizTitle}>{quiz.title}</h2>
          {quiz.questions.map((q, qi) => (
            <div key={qi} style={s.questionCard}>
              <p style={s.question}><strong>Q{qi+1}.</strong> {q.question}</p>
              <div style={s.options}>
                {['A','B','C','D'].map(opt => {
                  const val = q[`option_${opt.toLowerCase()}`];
                  const isSelected = answers[qi] === opt;
                  const isCorrect  = submitted && opt === q.correct;
                  const isWrong    = submitted && isSelected && opt !== q.correct;
                  return (
                    <button key={opt} disabled={submitted}
                      onClick={() => setAnswers(a => ({ ...a, [qi]: opt }))}
                      style={{ ...s.optBtn,
                        ...(isSelected && !submitted ? s.selected : {}),
                        ...(isCorrect ? s.correct : {}),
                        ...(isWrong ? s.wrong : {}),
                      }}>
                      <span style={s.optLabel}>{opt}</span> {val}
                    </button>
                  );
                })}
              </div>
              {submitted && q.explanation && (
                <p style={s.explanation}>💡 {q.explanation}</p>
              )}
            </div>
          ))}
          {!submitted ? (
            <button onClick={() => setSubmitted(true)} style={s.submitBtn}>Submit Answers</button>
          ) : (
            <div style={s.result}>
              <span style={s.scoreText}>{score}/{quiz.questions.length}</span>
              <span style={s.scoreLabel}>
                {score >= 4 ? '🏆 Excellent!' : score >= 3 ? '✅ Good job!' : '📚 Keep learning!'}
              </span>
              <button onClick={startQuiz} style={s.retryBtn}>Try Again</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

const DEMO_QUIZ = {
  title:'Quiz: General Civics',
  questions:[
    { question:'How many Fundamental Rights does the Indian Constitution guarantee?',
      option_a:'5', option_b:'7', option_c:'6', option_d:'9', correct:'C',
      explanation:'The Constitution guarantees 6 Fundamental Rights under Part III (Articles 12-35).' },
    { question:'When did the Indian Constitution come into effect?',
      option_a:'Aug 15 1947', option_b:'Jan 26 1950', option_c:'Nov 26 1949', option_d:'Jan 26 1952',
      correct:'B', explanation:'The Constitution came into effect on January 26, 1950, celebrated as Republic Day.' },
  ]
};

const s = {
  page: { maxWidth:900, margin:'0 auto', padding:'2rem 1rem', fontFamily:'DM Sans,sans-serif' },
  title: { fontSize:'2rem', color:'#ffd166', marginBottom:'.3rem' },
  sub: { color:'#7a98b0', marginBottom:'1.5rem' },
  topicRow: { display:'flex', flexWrap:'wrap', gap:'.5rem', marginBottom:'1.5rem' },
  topicBtn: { background:'rgba(255,209,102,.08)', border:'1px solid rgba(255,209,102,.2)',
    color:'#7a98b0', borderRadius:20, padding:'.4rem 1rem', cursor:'pointer', fontSize:'.9rem' },
  topicActive: { background:'rgba(255,209,102,.2)', borderColor:'#ffd166', color:'#ffd166', fontWeight:700 },
  startBtn: { background:'#ffd166', color:'#050a0e', border:'none', borderRadius:10,
    padding:'.85rem 2.5rem', fontSize:'1rem', fontWeight:700, cursor:'pointer', marginBottom:'2rem' },
  quizBox: { background:'#0d1821', borderRadius:16, padding:'2rem', border:'1px solid rgba(255,209,102,.15)' },
  quizTitle: { color:'#ffd166', marginBottom:'1.5rem', fontSize:'1.3rem' },
  questionCard: { background:'rgba(255,255,255,.03)', borderRadius:12, padding:'1.5rem', marginBottom:'1.5rem' },
  question: { color:'#e8f4f8', marginBottom:'1rem', lineHeight:1.5 },
  options: { display:'grid', gridTemplateColumns:'1fr 1fr', gap:'.75rem' },
  optBtn: { display:'flex', alignItems:'center', gap:'.5rem', background:'rgba(255,255,255,.04)',
    border:'1px solid rgba(255,255,255,.1)', color:'#e8f4f8', borderRadius:8, padding:'.75rem 1rem',
    cursor:'pointer', textAlign:'left', fontSize:'.9rem', transition:'all .15s' },
  optLabel: { background:'rgba(255,209,102,.2)', color:'#ffd166', borderRadius:4,
    padding:'0 .4rem', fontWeight:700, minWidth:20, textAlign:'center' },
  selected: { borderColor:'#a78bfa', background:'rgba(167,139,250,.12)' },
  correct: { borderColor:'#00f5d4', background:'rgba(0,245,212,.12)', color:'#00f5d4' },
  wrong: { borderColor:'#ff6b6b', background:'rgba(255,107,107,.12)', color:'#ff6b6b' },
  explanation: { color:'#a78bfa', fontSize:'.85rem', marginTop:'.75rem', fontStyle:'italic' },
  submitBtn: { background:'#ffd166', color:'#050a0e', border:'none', borderRadius:10,
    padding:'.85rem 2.5rem', fontSize:'1rem', fontWeight:700, cursor:'pointer', marginTop:'1rem' },
  result: { display:'flex', alignItems:'center', gap:'1.5rem', background:'rgba(0,245,212,.08)',
    borderRadius:12, padding:'1.5rem', marginTop:'1rem', flexWrap:'wrap' },
  scoreText: { fontSize:'3rem', fontWeight:700, color:'#00f5d4', fontFamily:'Bebas Neue,sans-serif' },
  scoreLabel: { fontSize:'1.1rem', color:'#e8f4f8' },
  retryBtn: { marginLeft:'auto', background:'transparent', border:'1px solid #00f5d4', color:'#00f5d4',
    borderRadius:8, padding:'.6rem 1.5rem', cursor:'pointer' },
};
