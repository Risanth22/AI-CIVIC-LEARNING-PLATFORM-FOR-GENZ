import axios from 'axios';

const API = axios.create({ baseURL: '/api', timeout: 10000 });
const AI  = axios.create({ baseURL: '/ai/api', timeout: 15000 });

API.interceptors.request.use(cfg => {
  const token = localStorage.getItem('civiciq_token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

export const register     = (data)           => API.post('/auth/register', data);
export const login        = (data)           => API.post('/auth/login', data);
export const getNews      = (params)         => API.get('/news', { params });
export const fetchLiveNews = ()              => AI.get('/news/fetch');
export const askTutor     = (question, lang) => AI.post('/tutor/ask', { question, language: lang || 'en' });
export const getPolls     = ()               => API.get('/polls');
export const getPollResults= (id)            => API.get(`/polls/${id}/results`);
export const votePoll     = (id, optionId)   => API.post(`/polls/${id}/vote`, { optionId });
export const getQuizzes   = (category)       => API.get('/quizzes', { params: { category } });
export const generateQuiz = (data)           => AI.post('/quiz/generate', data);
export const getBills     = (page)           => API.get('/bills', { params: { page: page||0, size: 10 } });
export const simulatePolicy = (data)         => AI.post('/policy/simulate', data);
export const translate    = (text, lang)     => AI.post('/translate', { text, target_language: lang });
